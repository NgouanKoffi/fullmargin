const { SESClient, SendEmailCommand } = require("@aws-sdk/client-ses");
const MailSettings = require("../models/mailSettings.model");
const MailTemplate = require("../models/mailTemplate.model");

/* =========================================================================
 * CONFIGURATION AWS SES
 * ========================================================================= */
const sesClient = new SESClient({
  region: process.env.AWS_REGION || "eu-north-1",
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

const ENV_FROM_EMAIL = process.env.MAIL_FROM || "noreply@fullmargin.net";
const ENV_FROM_NAME = process.env.APP_NAME || "FullMargin";
const APP_URL = "https://fullmargin.net";

/* =========================================================================
 * SETTINGS CACHE
 * ========================================================================= */
let _settingsCache = { data: null, at: 0 };
const SETTINGS_TTL_MS = 60_000;

async function getMailSettingsCached() {
  const now = Date.now();
  if (_settingsCache.data && now - _settingsCache.at < SETTINGS_TTL_MS) {
    return _settingsCache.data;
  }
  const doc = await MailSettings.findOne({ key: "global" }).lean();
  _settingsCache = { data: doc || null, at: now };
  return _settingsCache.data;
}

/* =========================================================================
 * RENDER HELPERS
 * ========================================================================= */
function getPath(ctx, path) {
  if (!path) return undefined;
  const parts = String(path).split(".");
  let acc = ctx;
  for (const k of parts) {
    if (acc == null) return undefined;
    if (typeof acc !== "object") return undefined;
    if (!(k in acc)) return undefined;
    acc = acc[k];
  }
  return acc;
}

function renderSections(tpl, ctx) {
  if (!tpl) return "";
  return tpl.replace(
    /\{\{\#\s*([a-zA-Z0-9_.]+)\s*\}\}([\s\S]*?)\{\{\/\s*\1\s*\}\}/g,
    (_m, path, inner) => {
      const isLen = /\.length$/.test(path);
      const basePath = isLen ? path.replace(/\.length$/, "") : path;
      const baseVal = getPath(ctx, basePath);

      let v = baseVal;
      if (isLen) {
        if (Array.isArray(baseVal)) v = baseVal.length;
        else if (typeof baseVal === "string") v = baseVal.length;
        else v = baseVal ? 1 : 0;
      }

      const truthy = Array.isArray(v) ? v.length > 0 : !!v;
      return truthy ? inner : "";
    }
  );
}

function renderVars(tpl, ctx) {
  if (!tpl) return "";
  return tpl.replace(/\{\{\s*([a-zA-Z0-9_.]+)\s*\}\}/g, (_m, path) => {
    const val = getPath(ctx, path);
    return val == null ? "" : String(val);
  });
}

function renderTemplate(tpl, ctx) {
  if (!tpl) return "";
  return renderVars(renderSections(tpl, ctx), ctx);
}

function stripHtml(html = "") {
  return String(html)
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<li>/gi, " • ")
    .replace(/<\/li>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .trim();
}

function normalizeCtx(ctx = {}) {
  const next = { ...ctx };
  const toLiHtml = (arr) => arr.map((n) => `<li>${String(n)}</li>`).join("");
  if (Array.isArray(next.addedNames))
    next.addedNames = toLiHtml(next.addedNames);
  if (Array.isArray(next.removedNames))
    next.removedNames = toLiHtml(next.removedNames);

  if (!next.app) next.app = {};
  if (!next.app.name) next.app.name = ENV_FROM_NAME;
  if (!next.app.url) next.app.url = APP_URL;
  return next;
}

/* =========================================================================
 * DEFAULT TEMPLATES
 * ========================================================================= */
const DEFAULTS = {
  "auth.login_code": {
    subject: "Votre code de connexion",
    html: `
<div style="font-family:Inter,Arial,sans-serif;font-size:16px;color:#111">
  <p>Bonjour,</p>
  <p>Votre code de connexion est :</p>
  <div style="font-size:28px;font-weight:700;letter-spacing:6px;margin:12px 0">{{code}}</div>
  <p>Il expire dans <b>2 minutes</b>.</p>
  <p>— {{app.name}}</p>
</div>`.trim(),
  },
  "auth.welcome": {
    subject: "Bienvenue sur {{app.name}} 🚀",
    html: `
<div style="font-family:Inter,Arial,sans-serif;font-size:16px;color:#111;line-height:1.5">
  <p>Bonjour {{user.firstName}},</p>
  <p>Ton compte <b>{{app.name}}</b> est prêt 🎉</p>
  <p>Tu peux dès maintenant te connecter et découvrir l'application.</p>
  <p style="margin:16px 0">
    <a href="{{app.url}}" style="display:inline-block;background:#111;color:#fff;text-decoration:none;padding:10px 16px;border-radius:10px;font-weight:600">
      Ouvrir {{app.name}}
    </a>
  </p>
  <p style="font-size:14px;color:#555">Si tu n’es pas à l’origine de cette inscription, ignore simplement cet email.</p>
  <p>— L’équipe {{app.name}}</p>
</div>`.trim(),
  },
  "auth.password_reset_code": {
    subject: "Réinitialisation du mot de passe",
    html: `
<div style="font-family:Inter,Arial,sans-serif;font-size:16px;color:#111">
  <p>Bonjour,</p>
  <p>Voici votre code pour réinitialiser votre mot de passe :</p>
  <div style="font-size:28px;font-weight:700;letter-spacing:6px;margin:12px 0">{{code}}</div>
  <p>Il expire dans <b>{{minutes}} minutes</b>.</p>
  <p>Si vous n'êtes pas à l'origine de cette demande, ignorez cet email.</p>
  <p>— {{app.name}}</p>
</div>`.trim(),
  },
  "service.membership_update": {
    subject: "Affectations de service — mise à jour",
    html: `
<div style="font-family:Inter,Arial,sans-serif;font-size:16px;color:#111;line-height:1.5">
  <p>Bonjour {{user.firstName}}!</p>
  <p>Vos affectations de service viennent d'être mises à jour.</p>
  {{#addedNames.length}}
    <p style="margin:8px 0"><b>Ajouté(s) :</b></p>
    <ul>{{addedNames}}</ul>
  {{/addedNames.length}}
  {{#removedNames.length}}
    <p style="margin:12px 0"><b>Retiré(s) :</b></p>
    <ul>{{removedNames}}</ul>
  {{/removedNames.length}}
  {{#becameAgent}}
    <p style="margin:12px 0"><b>Vous avez été promu(e) au grade « agent »</b>.</p>
  {{/becameAgent}}
  {{#lostAgent}}
    <p style="margin:12px 0"><b>Vous n'êtes plus « agent »</b>.</p>
  {{/lostAgent}}
  <p style="margin:16px 0">
    <a href="{{app.url}}" style="display:inline-block;background:#111;color:#fff;text-decoration:none;padding:10px 16px;border-radius:10px;font-weight:600">
      Ouvrir {{app.name}}
    </a>
  </p>
  <p style="font-size:14px;color:#555">Si vous pensez qu'il s'agit d'une erreur, merci de répondre à cet email.</p>
  <p>— L’équipe {{app.name}}</p>
</div>`.trim(),
  },
  "service.deleted": {
    subject: "Service supprimé — {{service.name}}",
    html: `
<div style="font-family:Inter,Arial,sans-serif;font-size:16px;color:#111;line-height:1.5">
  <p>Bonjour {{user.firstName}}!</p>
  <p>Le service <b>{{service.name}}</b> auquel vous apparteniez a été <b>supprimé</b>.</p>
  {{#wasDemoted}}
    <p><b>Conséquence :</b> vous n'êtes plus « agent » car aucun service ne vous est désormais attribué.</p>
  {{/wasDemoted}}
  <p style="margin:16px 0">
    <a href="{{app.url}}" style="display:inline-block;background:#111;color:#fff;text-decoration:none;padding:10px 16px;border-radius:10px;font-weight:600">
      Ouvrir {{app.name}}
    </a>
  </p>
  <p style="font-size:14px;color:#555">Si vous pensez qu'il s'agit d'une erreur, merci de répondre à cet email.</p>
  <p>— L’équipe {{app.name}}</p>
</div>`.trim(),
  },
};

/* =========================================================================
 * LOW-LEVEL SEND (AWS SES)
 * ========================================================================= */
async function sendEmail({
  to,
  subject,
  html,
  text,
  fromEmail,
  fromName,
  autoSignature = true,
  bcc = [],
}) {
  const settings = await getMailSettingsCached();

  const finalFromEmail = fromEmail || settings?.fromEmail || ENV_FROM_EMAIL;
  const finalFromName = fromName || settings?.fromName || ENV_FROM_NAME;

  let finalHtml = String(html || "");
  if (autoSignature) {
    let signatureHtml =
      settings?.signatureHtml ||
      `
<div style="font-family:Inter,Arial,sans-serif;font-size:14px;line-height:1.4;color:#111">
  <div><b>${finalFromName}</b></div>
  <div>Support • <a href="${APP_URL}" target="_blank" rel="noreferrer">${APP_URL.replace(
        /^https?:\/\//,
        ""
      )}</a></div>
</div>`.trim();
    const separator = `<hr style="border:none;border-top:1px solid #e5e7eb;margin:16px 0" />`;
    finalHtml = `${finalHtml}\n${separator}\n${signatureHtml}`;
  }

  const finalText = text || stripHtml(finalHtml);

  const command = new SendEmailCommand({
    Destination: {
      ToAddresses: [to],
      BccAddresses: bcc.length > 0 ? bcc : undefined,
    },
    Message: {
      Subject: { Data: subject },
      Body: {
        Html: { Data: finalHtml },
        Text: { Data: finalText },
      },
    },
    Source: `"${finalFromName}" <${finalFromEmail}>`,
  });

  try {
    const result = await sesClient.send(command);
    return result;
  } catch (error) {
    console.error("[AWS SES] Erreur d'envoi d'email:", error);
    throw error;
  }
}

/* =========================================================================
 * PIPELINE (template -> render -> send)
 * ========================================================================= */
async function loadSettingsAndTemplate(slug) {
  const [settings, tpl] = await Promise.all([
    getMailSettingsCached(),
    slug ? MailTemplate.findOne({ slug }).lean() : null,
  ]);
  return { settings, tpl };
}

function withDefaults(slug) {
  return DEFAULTS[slug] || {};
}

async function renderAndSend(
  slug,
  { to, subjectFallback, htmlFallback, context = {} }
) {
  if (!to) return;

  const { tpl } = await loadSettingsAndTemplate(slug);
  const def = withDefaults(slug);

  const ctx = normalizeCtx(context);
  const subjectT =
    (tpl && tpl.subject) || def.subject || subjectFallback || "(Sans sujet)";
  const htmlT = (tpl && tpl.html) || def.html || htmlFallback || "";

  const subject = renderTemplate(subjectT, ctx);
  const html = renderTemplate(htmlT, ctx);

  await sendEmail({ to, subject, html });
}

/* =========================================================================
 * HIGH-LEVEL HELPERS
 * ========================================================================= */
async function sendLoginCode(to, code) {
  if (process.env.NODE_ENV !== "production") {
    console.log(`[2FA] Code pour ${to}: ${code}`);
  }
  await renderAndSend("auth.login_code", { to, context: { code } });
}

async function sendWelcomeEmail(to, fullName = "") {
  const firstName = String(fullName || "").split(" ")[0] || "Bienvenue";
  await renderAndSend("auth.welcome", {
    to,
    context: { user: { firstName, fullName } },
  });
}

async function sendPasswordResetCode(to, code, minutes = 10) {
  if (process.env.NODE_ENV !== "production") {
    console.log(`[RESET] Code pour ${to}: ${code} (expire ${minutes} min)`);
  }
  await renderAndSend("auth.password_reset_code", {
    to,
    context: { code, minutes },
  });
}

async function sendMembershipUpdateEmail({
  to,
  fullName = "",
  addedNames = [],
  removedNames = [],
  becameAgent = false,
  lostAgent = false,
}) {
  const firstName = String(fullName || "").split(" ")[0] || "";
  await renderAndSend("service.membership_update", {
    to,
    context: {
      user: { firstName, fullName },
      addedNames,
      removedNames,
      becameAgent,
      lostAgent,
    },
  });
}

async function sendServiceDeletedEmail({
  to,
  fullName = "",
  serviceName = "",
  wasDemoted = false,
}) {
  const firstName = String(fullName || "").split(" ")[0] || "";
  await renderAndSend("service.deleted", {
    to,
    context: {
      user: { firstName, fullName },
      service: { name: serviceName || "Service" },
      wasDemoted: !!wasDemoted,
    },
  });
}

/* =========================================================================
 * EXPORTS
 * ========================================================================= */
module.exports = {
  sendEmail,
  sendBulkEmail: async function sendBulkEmail({
    recipients,
    subject,
    html,
    text,
    fromEmail,
    fromName,
    attachments = [],
    chunkSize = 50, // Limite sécurisée pour AWS SES
  }) {
    const dedup = Array.from(
      new Set(recipients.map((e) => String(e).toLowerCase()).filter(Boolean))
    );
    for (let i = 0; i < dedup.length; i += chunkSize) {
      const slice = dedup.slice(i, i + chunkSize);
      // AWS SES préfère les envois individuels ou via des listes spécifiques,
      // ici on boucle pour garder la compatibilité avec ton code.
      for (const recipient of slice) {
        await sendEmail({
          to: recipient,
          subject,
          html,
          text,
          fromEmail,
          fromName,
        });
      }
    }
  },
  sendLoginCode,
  sendWelcomeEmail,
  sendPasswordResetCode,
  sendMembershipUpdateEmail,
  sendServiceDeletedEmail,
};
