// backend/src/utils/mailer.render.js

const ENV_FROM_NAME =
  process.env.MAIL_FROM_NAME || process.env.APP_NAME || "FullMargin";

const APP_URL =
  process.env.APP_URL ||
  (process.env.NODE_ENV === "production"
    ? "https://fullmargin.net"
    : "http://localhost:5173");

/** ✅ Support WhatsApp */
const SUPPORT_WHATSAPP_E164 =
  process.env.SUPPORT_WHATSAPP_E164 || "33652395381";

function getPath(ctx, path) {
  if (!path) return undefined;
  const parts = String(path).split(".");
  let acc = ctx;
  for (const k of parts) {
    if (acc == null) return undefined;
    if (typeof acc !== "object") return undefined;
    if (!(k in acc)) return undefined;
    acc = acc[k];
  }
  return acc;
}

function renderSections(tpl, ctx) {
  if (!tpl) return "";
  return tpl.replace(
    /\{\{\#\s*([a-zA-Z0-9_.]+)\s*\}\}([\s\S]*?)\{\{\/\s*\1\s*\}\}/g,
    (_m, path, inner) => {
      const isLen = /\.length$/.test(path);
      const basePath = isLen ? path.replace(/\.length$/, "") : path;

      const baseVal = getPath(ctx, basePath);

      let v = baseVal;
      if (isLen) {
        if (Array.isArray(baseVal)) v = baseVal.length;
        else if (typeof baseVal === "string") v = baseVal.length;
        else v = baseVal ? 1 : 0;
      }

      const truthy = Array.isArray(v) ? v.length > 0 : !!v;
      return truthy ? inner : "";
    },
  );
}

function renderVars(tpl, ctx) {
  if (!tpl) return "";
  return tpl.replace(/\{\{\s*([a-zA-Z0-9_.]+)\s*\}\}/g, (_m, path) => {
    const val = getPath(ctx, path);
    return val == null ? "" : String(val);
  });
}

function renderTemplate(tpl, ctx) {
  if (!tpl) return "";
  return renderVars(renderSections(tpl, ctx), ctx);
}

function stripHtml(html = "") {
  return String(html)
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<li>/gi, " • ")
    .replace(/<\/li>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .trim();
}

function normalizeCtx(ctx = {}) {
  const next = { ...ctx };
  const toLiHtml = (arr) => arr.map((n) => `<li>${String(n)}</li>`).join("");

  if (Array.isArray(next.addedNames))
    next.addedNames = toLiHtml(next.addedNames);
  if (Array.isArray(next.removedNames))
    next.removedNames = toLiHtml(next.removedNames);

  if (!next.app) next.app = {};
  if (!next.app.name) next.app.name = ENV_FROM_NAME;
  if (!next.app.url) next.app.url = APP_URL;

  // ✅ Support ctx (WhatsApp)
  if (!next.support) next.support = {};
  if (!next.support.whatsappNumber)
    next.support.whatsappNumber = SUPPORT_WHATSAPP_E164;
  if (!next.support.whatsappUrl)
    next.support.whatsappUrl = `https://wa.me/${next.support.whatsappNumber}`;

  return next;
}

function fmtFrDate(isoOrDate) {
  if (!isoOrDate) return "";
  try {
    const d =
      isoOrDate instanceof Date ? isoOrDate : new Date(String(isoOrDate));
    if (!Number.isFinite(d.getTime())) return "";
    return d
      .toLocaleString("fr-FR", {
        year: "numeric",
        month: "short",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      })
      .replaceAll("\u202f", " ");
  } catch {
    return "";
  }
}

function computeExpiryLabel(expiresAt, isLifetime) {
  if (isLifetime) return "Accès illimité";
  const fr = fmtFrDate(expiresAt);
  return fr || "—";
}

module.exports = {
  getPath,
  renderSections,
  renderVars,
  renderTemplate,
  stripHtml,
  normalizeCtx,
  fmtFrDate,
  computeExpiryLabel,
};
