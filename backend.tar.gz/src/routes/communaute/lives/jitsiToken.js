const jwt = require("jsonwebtoken");
const { requireAuth, assertCanView, CommunityLive } = require("./_shared");

function safeName(raw) {
  let s = String(raw || "");
  try {
    s = s.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  } catch {
    // ignore normalize errors
  }
  s = s
    .replace(/[^A-Za-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 60);
  return s;
}

/**
 * GET /api/communaute/lives/:id/jitsi-token?name=...
 * -> retourne un JWT Jitsi pour rejoindre la room
 */
module.exports = (router) => {
  router.get("/:id/jitsi-token", requireAuth, async (req, res) => {
    const userId = String(req.auth.userId);
    const { id } = req.params;

    const JITSI_DOMAIN = process.env.JITSI_DOMAIN || "live.fullmargin.net";
    const APP_ID = process.env.JITSI_APP_ID;
    const APP_SECRET = process.env.JITSI_APP_SECRET;

    if (!APP_ID || !APP_SECRET) {
      return res.status(500).json({
        ok: false,
        error: "Config Jitsi JWT manquante (JITSI_APP_ID / JITSI_APP_SECRET).",
      });
    }

    try {
      const live = await CommunityLive.findById(id).lean();
      if (!live) {
        return res.status(404).json({ ok: false, error: "Live introuvable." });
      }

      const check = await assertCanView(
        userId,
        String(live.communityId),
        !!live.isPublic
      );
      if (!check.ok) {
        return res.status(403).json({ ok: false, error: check.error });
      }

      const community = check.community;
      const isCommunityOwner =
        community && String(community.ownerId) === String(userId);
      const isLiveCreator = String(live.createdBy) === String(userId);
      const isOwner = !!(isCommunityOwner || isLiveCreator);

      const displayName = safeName(req.query.name) || "Membre FullMargin";

      const cleanRoomName = String(live.roomName).replace(/[^a-zA-Z0-9]/g, "");

      // Construction du payload Jitsi JWT - VERSION HEX-SECRET
      const now = Math.floor(Date.now() / 1000);
      const payload = {
        aud: "jitsi", 
        iss: APP_ID,
        sub: JITSI_DOMAIN,
        room: cleanRoomName, 
        iat: now,
        nbf: now - 300, 
        exp: now + 3600,
        moderator: isOwner,
        context: {
          user: {
            id: userId,
            name: displayName,
            email: req.auth.email || "",
            moderator: isOwner, 
          },
          features: {
            livestreaming: true,
            recording: true,
            transcription: true,
          }
        },
      };

      // ⚠️ IMPORTANT: Jitsi utilise souvent des secrets en HEX. 
      // Si la chaîne fait 64 caractères, on la traite comme du binaire (Buffer).
      let secret = APP_SECRET;
      if (APP_SECRET.length === 64 && /^[0-9a-fA-F]+$/.test(APP_SECRET)) {
        secret = Buffer.from(APP_SECRET, "hex");
      }

      const token = jwt.sign(payload, secret, { algorithm: "HS256" });

      return res.json({
        ok: true,
        data: {
          token,
          room: live.roomName,
          isOwner: !!isOwner,
        },
      });
    } catch (e) {
      console.error("[LIVES] GET /:id/jitsi-token ERROR:", e);
      return res.status(500).json({
        ok: false,
        error: "Impossible de générer le token Jitsi.",
      });
    }
  });
};
