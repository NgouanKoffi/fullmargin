// backend/src/routes/communaute/posts/listPosts.js
const {
  Community,
  CommunityPost,
  CommunityPostLike,
  CommunityComment,
  User,
  CommunityMember,
} = require("./_shared");

module.exports = async function listPosts(req, res) {
  try {
    const rawId = String(req.query.communityId || "").trim();
    const hasId = /^[a-f0-9]{24}$/i.test(rawId);

    const page = Math.max(parseInt(String(req.query.page || "1"), 10) || 1, 1);
    const limit = Math.min(
      Math.max(parseInt(String(req.query.limit || "10"), 10) || 10, 1),
      30
    );

    const userId = req.auth?.userId ? String(req.auth.userId) : null;

    // 🆕 scope : "my-communities" / "public-others"
    const rawScope = String(req.query.scope || "").trim();
    const scope =
      rawScope === "my-communities"
        ? "my-communities"
        : rawScope === "public-others"
        ? "public-others"
        : null;

    // base : uniquement posts publiés & non supprimés
    const q = {
      deletedAt: null,
      $or: [{ isPublished: true }, { isPublished: { $exists: false } }],
    };
    if (hasId) q.communityId = rawId;

    // on récupère la page brute
    const rows = await CommunityPost.find(q)
      .sort({ publishedAt: -1, createdAt: -1, _id: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .lean();

    // 🔐 appliquer la logique de visibilité
    let visibleRows = rows;

    // ensembles pour appartenance à une communauté
    let memberSet = new Set();
    let ownerSet = new Set();

    if (!userId) {
      // ❌ pas connecté → uniquement posts publics (ou anciens sans visibility)
      visibleRows = rows.filter((r) => {
        const v = r.visibility || "public";
        return v === "public";
      });
    } else {
      // ✅ connecté → publics + privés si membre, auteur OU owner
      const communityIds = [
        ...new Set(rows.map((r) => String(r.communityId || ""))),
      ].filter(Boolean);

      if (communityIds.length) {
        // on récupère en parallèle : memberships + communautés dont je suis owner
        const [members, owned] = await Promise.all([
          CommunityMember.find({
            communityId: { $in: communityIds },
            userId,
            $or: [{ status: "active" }, { status: { $exists: false } }],
          })
            .select({ communityId: 1 })
            .lean(),
          Community.find({
            _id: { $in: communityIds },
            ownerId: userId,
            deletedAt: null,
          })
            .select({ _id: 1 })
            .lean(),
        ]);

        memberSet = new Set(members.map((m) => String(m.communityId)));
        ownerSet = new Set(owned.map((c) => String(c._id)));
      }

      const isInMyCommunities = (cid) =>
        memberSet.has(cid) || ownerSet.has(cid);

      visibleRows = rows.filter((r) => {
        const v = r.visibility || "public";
        const cid = String(r.communityId);
        const isMember = memberSet.has(cid);
        const isOwner = ownerSet.has(cid);
        const isAuthor = String(r.authorId) === userId;

        // public → toujours visible
        if (v === "public") return true;

        // private → visible si membre, auteur OU owner de la communauté
        return isMember || isAuthor || isOwner;
      });

      // 🆕 filtre supplémentaire selon scope
      if (scope === "my-communities") {
        visibleRows = visibleRows.filter((r) => {
          const cid = String(r.communityId || "");
          const v = r.visibility || "public";
          const inMy = isInMyCommunities(cid);
          const isAuthor = String(r.authorId) === userId;
          // → posts des communautés où je suis membre/owner
          //    + mes propres posts (au cas où je ne serais plus membre)
          return inMy || isAuthor;
        });
      } else if (scope === "public-others") {
        visibleRows = visibleRows.filter((r) => {
          const cid = String(r.communityId || "");
          const v = r.visibility || "public";
          const inMy = isInMyCommunities(cid);
          // → seulement posts PUBLICS des communautés où je ne suis pas abonné
          return !inMy && v === "public";
        });
      }
    }

    const postIds = visibleRows.map((r) => r._id);

    const likesAgg = await CommunityPostLike.aggregate([
      { $match: { postId: { $in: postIds } } },
      { $group: { _id: "$postId", count: { $sum: 1 } } },
    ]);
    const likesByPostId = new Map(
      likesAgg.map((x) => [String(x._id), x.count || 0])
    );

    const commentsAgg = await CommunityComment.aggregate([
      { $match: { postId: { $in: postIds }, deletedAt: null } },
      { $group: { _id: "$postId", count: { $sum: 1 } } },
    ]);
    const commentsByPostId = new Map(
      commentsAgg.map((x) => [String(x._id), x.count || 0])
    );

    let likedSet = new Set();
    if (userId) {
      const mine = await CommunityPostLike.find({
        postId: { $in: postIds },
        userId,
      })
        .select({ postId: 1 })
        .lean();
      likedSet = new Set(mine.map((m) => String(m.postId)));
    }

    const authorIds = [...new Set(visibleRows.map((r) => String(r.authorId)))];
    const authors = await User.find({ _id: { $in: authorIds } })
      .select({ _id: 1, fullName: 1, avatarUrl: 1 })
      .lean();
    const byId = new Map(authors.map((u) => [String(u._id), u]));

    const items = visibleRows.map((r) => {
      const liveLikes = likesByPostId.get(String(r._id)) ?? 0;
      const liveComments = commentsByPostId.get(String(r._id)) ?? 0;
      const a = byId.get(String(r.authorId));

      const authorPayload = {
        id: String(r.authorId),
        name: a?.fullName || "",
        fullName: a?.fullName || "",
        avatarUrl: a?.avatarUrl || "",
      };

      return {
        id: String(r._id),
        communityId: String(r.communityId),
        author: authorPayload,
        authorName: authorPayload.fullName,
        authorFullName: authorPayload.fullName,
        authorAvatarUrl: authorPayload.avatarUrl,
        content: r.content || "",
        media: (r.media || []).map((m) => ({
          kind: m.kind === "video" ? "video" : "image",
          type: m.kind === "video" ? "video" : "image",
          url: m.url,
          thumbnail: m.thumbnail || "",
          publicId: m.publicId || "",
          width: m.width,
          height: m.height,
          duration: m.duration,
        })),
        likes: liveLikes,
        likedByMe: likedSet.has(String(r._id)),
        comments: liveComments,
        createdAt: r.createdAt,
        isPublished: typeof r.isPublished === "boolean" ? r.isPublished : true,
        publishedAt: r.publishedAt || null,
        deletedAt: r.deletedAt
          ? r.deletedAt.toISOString?.() || r.deletedAt
          : undefined,
        visibility: r.visibility || "public",
      };
    });

    // ⚠️ hasMore doit se baser sur rows (page brute), pas sur items filtrés
    const hasMore = rows.length === limit;

    return res.json({
      ok: true,
      data: { items, page, limit, hasMore, total: items.length },
    });
  } catch (e) {
    console.error("[POSTS] list ERROR:", e?.stack || e);
    return res.status(500).json({ ok: false, error: "Lecture impossible" });
  }
};
