// C:\Users\ADMIN\Desktop\fullmargin-site\backend\src\routes\admin\marketplace.orders.js
const express = require("express");
const mongoose = require("mongoose");
const Order = require("../../models/order.model");
const User = require("../../models/user.model");
const { verifyAuthHeader } = require("../auth/_helpers");

// ✅ IMPORTS AJOUTÉS POUR EMAILS ET LIVRAISON
const Mailer = require("../../utils/mailer");
const {
  handleMarketplacePaymentEvent,
} = require("../payments/handlers/marketplace.handler");

const router = express.Router();

function requireAuth(req, res, next) {
  try {
    const a = verifyAuthHeader(req);
    if (!a || !a.userId)
      return res.status(401).json({ ok: false, error: "Non autorisé" });
    req.auth = { userId: String(a.userId) };
    next();
  } catch {
    return res.status(401).json({ ok: false, error: "Non autorisé" });
  }
}

async function requireAdminOrAgent(req, res, next) {
  try {
    const me = await User.findById(req.auth.userId).select("roles").lean();
    const roles = Array.isArray(me?.roles) ? me.roles : [];
    const ok = roles.includes("admin") || roles.includes("agent");
    if (!ok) return res.status(403).json({ ok: false, error: "Accès refusé" });
    next();
  } catch (e) {
    return res.status(500).json({ ok: false, error: "Erreur auth roles" });
  }
}

function buildQueryByStatus(statuses, q) {
  const query = { deletedAt: null, status: { $in: statuses } };

  const s = String(q || "").trim();
  if (!s) return query;

  // ID complet
  if (mongoose.Types.ObjectId.isValid(s) && s.length === 24) {
    query._id = s;
    return query;
  }

  // fallback: recherche titre item (simple)
  query["items.title"] = {
    $regex: s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
    $options: "i",
  };
  return query;
}

// GET /api/admin/marketplace/orders/pending
router.get("/pending", requireAuth, requireAdminOrAgent, async (req, res) => {
  try {
    const q = req.query.q || "";
    const query = buildQueryByStatus(["requires_payment"], q);

    const rows = await Order.find(query)
      .sort({ createdAt: -1 })
      .populate("user", "email name")
      .select(
        "_id user status currency totalAmount totalAmountCents createdAt paidAt items crypto",
      )
      .lean();

    return res.json({ ok: true, data: { items: rows } });
  } catch (e) {
    console.error("[admin orders pending]", e?.stack || e);
    return res.status(500).json({ ok: false, error: "Chargement impossible" });
  }
});

// GET /api/admin/marketplace/orders/paid
router.get("/paid", requireAuth, requireAdminOrAgent, async (req, res) => {
  try {
    const q = req.query.q || "";
    const query = buildQueryByStatus(["succeeded"], q);

    const rows = await Order.find(query)
      .sort({ createdAt: -1 })
      .populate("user", "email name")
      .select(
        "_id user status currency totalAmount totalAmountCents createdAt paidAt items",
      )
      .lean();

    return res.json({ ok: true, data: { items: rows } });
  } catch (e) {
    console.error("[admin orders paid]", e?.stack || e);
    return res.status(500).json({ ok: false, error: "Chargement impossible" });
  }
});

// GET /api/admin/marketplace/orders/closed
router.get("/closed", requireAuth, requireAdminOrAgent, async (req, res) => {
  try {
    const q = req.query.q || "";
    const query = buildQueryByStatus(["canceled", "failed"], q);

    const rows = await Order.find(query)
      .sort({ createdAt: -1 })
      .populate("user", "email name")
      .select(
        "_id user status currency totalAmount totalAmountCents createdAt paidAt items",
      )
      .lean();

    return res.json({ ok: true, data: { items: rows } });
  } catch (e) {
    console.error("[admin orders closed]", e?.stack || e);
    return res.status(500).json({ ok: false, error: "Chargement impossible" });
  }
});

// POST /api/admin/marketplace/orders/:id/validate
router.post(
  "/:id/validate",
  requireAuth,
  requireAdminOrAgent,
  async (req, res) => {
    try {
      const id = String(req.params.id || "");
      if (!mongoose.Types.ObjectId.isValid(id)) {
        return res.status(400).json({ ok: false, error: "ID invalide" });
      }

      // 1. Mise à jour statut + infos crypto
      const order = await Order.findOneAndUpdate(
        { _id: id, deletedAt: null },
        {
          $set: {
            status: "succeeded",
            paidAt: new Date(),
            "crypto.status": "approved",
            "crypto.approvedAt": new Date(),
          },
        },
        { new: true },
      )
        .populate("user", "email name profile") // Ajout de profile pour le nom complet
        .lean();

      if (!order)
        return res
          .status(404)
          .json({ ok: false, error: "Commande introuvable" });

      // 2. ✅ Déclenchement Livraison (Licences, Commissions...)
      await handleMarketplacePaymentEvent({
        status: "success",
        meta: { orderId: String(order._id) },
      });

      // 3. ✅ Envoi Email Succès
      if (order.user?.email) {
        const userName =
          order.user.name || order.user.profile?.fullName || "Client";
        const productTitle = order.items?.[0]?.title || "Commande Marketplace";

        await Mailer.sendMarketplaceCryptoApprovedEmail({
          to: order.user.email,
          fullName: userName,
          productTitle,
        }).catch((err) => console.error("[Mail] Erreur envoi approved:", err));
      }

      return res.json({ ok: true, data: { order } });
    } catch (e) {
      console.error("[admin orders validate]", e?.stack || e);
      return res
        .status(500)
        .json({ ok: false, error: "Validation impossible" });
    }
  },
);

// POST /api/admin/marketplace/orders/:id/cancel
router.post(
  "/:id/cancel",
  requireAuth,
  requireAdminOrAgent,
  async (req, res) => {
    try {
      const id = String(req.params.id || "");
      const { reason } = req.body; // On récupère le motif envoyé par le front

      if (!mongoose.Types.ObjectId.isValid(id)) {
        return res.status(400).json({ ok: false, error: "ID invalide" });
      }

      // 1. Mise à jour statut + motif rejet
      const order = await Order.findOneAndUpdate(
        { _id: id, deletedAt: null },
        {
          $set: {
            status: "canceled",
            "crypto.status": "rejected",
            "crypto.rejectedAt": new Date(),
            "crypto.rejectReason": reason || null,
          },
        },
        { new: true },
      )
        .populate("user", "email name profile")
        .lean();

      if (!order)
        return res
          .status(404)
          .json({ ok: false, error: "Commande introuvable" });

      // 2. ✅ Envoi Email Rejet avec Motif
      if (order.user?.email) {
        const userName =
          order.user.name || order.user.profile?.fullName || "Client";
        const productTitle = order.items?.[0]?.title || "Commande Marketplace";

        await Mailer.sendMarketplaceCryptoRejectedEmail({
          to: order.user.email,
          fullName: userName,
          productTitle,
          reason: reason || "Paiement non valide.",
        }).catch((err) => console.error("[Mail] Erreur envoi rejected:", err));
      }

      return res.json({ ok: true, data: { order } });
    } catch (e) {
      console.error("[admin orders cancel]", e?.stack || e);
      return res
        .status(500)
        .json({ ok: false, error: "Annulation impossible" });
    }
  },
);

module.exports = router;
