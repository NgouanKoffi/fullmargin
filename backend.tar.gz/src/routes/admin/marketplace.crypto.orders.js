// backend/src/routes/admin/marketplace.crypto.orders.js
const express = require("express");
const router = express.Router();

const Order = require("../../models/order.model");
const User = require("../../models/user.model");
const { verifyAuthHeader } = require("../auth/_helpers");

function requireAuth(req, res, next) {
  try {
    const a = verifyAuthHeader(req);
    if (!a || !a.userId)
      return res.status(401).json({ ok: false, error: "Non autorisé" });
    req.auth = { userId: String(a.userId) };
    next();
  } catch {
    return res.status(401).json({ ok: false, error: "Non autorisé" });
  }
}

async function requireAdminOrAgent(req, res, next) {
  try {
    const me = await User.findById(req.auth.userId).select("roles").lean();
    const roles = Array.isArray(me?.roles) ? me.roles : [];
    const ok = roles.includes("admin") || roles.includes("agent");
    if (!ok) return res.status(403).json({ ok: false, error: "Accès refusé" });
    next();
  } catch (e) {
    console.error("[admin marketplace crypto] role check error:", e);
    return res.status(403).json({ ok: false, error: "Accès refusé" });
  }
}

const toISO = (d) => {
  try {
    return (d instanceof Date ? d : new Date(d)).toISOString();
  } catch {
    return "";
  }
};

/**
 * ✅ Filtre crypto robuste :
 * - provider === "crypto"
 * - ou (fallback) stripe ids vides + paymentReference non vide
 */
function buildCryptoFilter() {
  return {
    $or: [
      { provider: "crypto" },
      {
        $and: [
          {
            $or: [
              { "stripe.checkoutSessionId": "" },
              { "stripe.checkoutSessionId": null },
            ],
          },
          {
            $or: [
              { "stripe.paymentIntentId": "" },
              { "stripe.paymentIntentId": null },
            ],
          },
          { paymentReference: { $type: "string", $ne: "" } },
        ],
      },
    ],
  };
}

/* ============================================================
   GET /api/admin/marketplace/orders/crypto/pending
============================================================ */
router.get("/pending", requireAuth, requireAdminOrAgent, async (req, res) => {
  try {
    const q = String(req.query.q || "")
      .trim()
      .toLowerCase();
    const limit = Math.min(500, Math.max(1, Number(req.query.limit || 200)));

    const baseQuery = {
      deletedAt: null,
      status: "requires_payment",
      ...buildCryptoFilter(),
    };

    // recherche simple (email, ref, id)
    const query = { ...baseQuery };
    if (q) {
      query.$or = [
        { paymentReference: { $regex: q, $options: "i" } },
        { _id: q.match(/^[0-9a-fA-F]{24}$/) ? q : undefined },
      ].filter(Boolean);
    }

    const orders = await Order.find(query)
      .sort({ createdAt: -1, _id: -1 })
      .limit(limit)
      .populate({
        path: "user",
        select: "email profile.fullName profile.name",
      })
      .lean();

    const items = (orders || []).map((o) => {
      const buyer = o.user || null;
      const buyerName =
        buyer?.profile?.fullName ||
        buyer?.profile?.name ||
        (buyer?.email ? String(buyer.email).split("@")[0] : "") ||
        "—";

      return {
        id: String(o._id),
        createdAt: toISO(o.createdAt),
        currency: String(o.currency || "usd").toUpperCase(),
        totalAmount: Number(o.totalAmount || 0),
        status: String(o.status || "requires_payment"),
        provider: String(o.provider || "crypto"),
        paymentReference: String(o.paymentReference || o.crypto?.txHash || ""),
        crypto: {
          network: String(o.crypto?.network || ""),
          txHash: String(o.crypto?.txHash || ""),
          note: String(o.crypto?.note || ""),
        },
        buyer: {
          id: buyer?._id ? String(buyer._id) : "",
          email: buyer?.email ? String(buyer.email) : null,
          name: buyerName,
        },
        itemCount: Array.isArray(o.items) ? o.items.length : 0,
        itemsPreview: Array.isArray(o.items)
          ? o.items.slice(0, 3).map((it) => ({
              title: String(it.title || ""),
              qty: Number(it.qty || 1),
              unitAmount: Number(it.unitAmount || 0),
            }))
          : [],
      };
    });

    res.set("Cache-Control", "no-store");
    return res.status(200).json({ ok: true, items });
  } catch (e) {
    console.error(
      "[admin marketplace crypto] list pending error:",
      e?.stack || e,
    );
    return res.status(500).json({ ok: false, error: "Chargement impossible" });
  }
});

/* ============================================================
   POST /api/admin/marketplace/orders/crypto/:id/approve
   -> Valide manuellement : status=succeeded + paidAt
============================================================ */
router.post(
  "/:id/approve",
  requireAuth,
  requireAdminOrAgent,
  async (req, res) => {
    try {
      const id = String(req.params.id || "");
      const note = typeof req.body?.note === "string" ? req.body.note : "";
      const txHash =
        typeof req.body?.txHash === "string" ? req.body.txHash : "";

      const order = await Order.findOne({ _id: id, deletedAt: null });
      if (!order)
        return res
          .status(404)
          .json({ ok: false, error: "Commande introuvable" });

      if (order.status === "succeeded") {
        return res.status(200).json({ ok: true, already: true });
      }

      order.status = "succeeded";
      order.paidAt = new Date();
      order.provider = order.provider || "crypto";

      if (txHash) order.crypto.txHash = txHash;
      if (note) order.crypto.note = note;

      order.crypto.validatedAt = new Date();
      order.crypto.validatedBy = req.auth.userId;

      await order.save();

      // ⚠️ IMPORTANT :
      // Si tu crées des SellerPayout / délivrance produit sur webhook Stripe,
      // ici tu dois déclencher le même pipeline pour crypto (à brancher).
      // -> TODO: generate payouts + grant access/downloads.

      res.set("Cache-Control", "no-store");
      return res.status(200).json({ ok: true });
    } catch (e) {
      console.error("[admin marketplace crypto] approve error:", e?.stack || e);
      return res
        .status(500)
        .json({ ok: false, error: "Validation impossible" });
    }
  },
);

/* ============================================================
   POST /api/admin/marketplace/orders/crypto/:id/reject
   -> Rejette : status=failed
============================================================ */
router.post(
  "/:id/reject",
  requireAuth,
  requireAdminOrAgent,
  async (req, res) => {
    try {
      const id = String(req.params.id || "");
      const reason =
        typeof req.body?.reason === "string" ? req.body.reason : "";

      const order = await Order.findOne({ _id: id, deletedAt: null });
      if (!order)
        return res
          .status(404)
          .json({ ok: false, error: "Commande introuvable" });

      if (order.status === "succeeded") {
        return res
          .status(400)
          .json({ ok: false, error: "Commande déjà payée" });
      }

      order.status = "failed";
      order.crypto.rejectedAt = new Date();
      order.crypto.rejectedBy = req.auth.userId;
      order.crypto.rejectionReason = reason || "Paiement crypto non confirmé";

      await order.save();

      res.set("Cache-Control", "no-store");
      return res.status(200).json({ ok: true });
    } catch (e) {
      console.error("[admin marketplace crypto] reject error:", e?.stack || e);
      return res.status(500).json({ ok: false, error: "Rejet impossible" });
    }
  },
);

module.exports = router;
