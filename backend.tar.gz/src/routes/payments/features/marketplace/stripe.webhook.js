// backend/src/routes/payments/features/marketplace/stripe.webhook.js
const Order = require("../../../../models/order.model");
const Promo = require("../../../../models/promoCode.model");
const {
  ensurePayoutsForOrder,
} = require("../../../../services/payouts.service");
const {
  ensureLicensesForOrder,
} = require("../../../../services/licenses/ensureLicensesForOrder");

const { hydrateOrderFromStripe } = require("./stripe.hydrate");

async function handleMarketplaceStripeEvent({ stripe, event, object }) {
  if (!stripe || !event) return;

  try {
    if (event.type === "payment_intent.succeeded") {
      const pi = await stripe.paymentIntents.retrieve(object.id, {
        expand: [
          "latest_charge",
          "latest_charge.balance_transaction",
          "payment_method",
        ],
      });

      const order = await Order.findOne({ "stripe.paymentIntentId": pi.id });
      if (order) {
        await hydrateOrderFromStripe({ order, pi, stripe });
        await order.save();

        if (order.status === "succeeded") {
          // promo usage
          try {
            const usages = new Map();
            for (const it of order.items || []) {
              const code = it?.promo?.code;
              if (!code) continue;
              const q = Math.max(1, Number(it.qty) || 1);
              usages.set(code, (usages.get(code) || 0) + q);
            }
            if (usages.size > 0) {
              const ops = [];
              for (const [code, inc] of usages.entries()) {
                ops.push(
                  Promo.updateOne(
                    { code: String(code).toUpperCase(), deletedAt: null },
                    { $inc: { used: inc } }
                  ).catch(() => null)
                );
              }
              await Promise.allSettled(ops);
            }
          } catch (err) {
            console.warn(
              "[PROMO] increment usage in webhook(pi):",
              err?.message || err
            );
          }

          // ✅ licences puis payouts
          await ensureLicensesForOrder(order._id);
          await ensurePayoutsForOrder(order);
        }
      }
    } else if (event.type === "payment_intent.payment_failed") {
      const order = await Order.findOne({
        "stripe.paymentIntentId": object.id,
      });
      if (order) {
        order.status = "failed";
        await order.save();
      }
    } else if (event.type === "checkout.session.completed") {
      const s = await stripe.checkout.sessions.retrieve(object.id, {
        expand: [
          "payment_intent",
          "customer_details",
          "payment_intent.latest_charge",
          "payment_intent.latest_charge.balance_transaction",
          "payment_intent.payment_method",
        ],
      });

      const order =
        (await Order.findOne({ "stripe.checkoutSessionId": s.id })) ||
        (await Order.findOne({ _id: s?.metadata?.orderId }));

      if (order) {
        await hydrateOrderFromStripe({
          order,
          session: s,
          pi: s.payment_intent,
          stripe,
        });
        await order.save();

        if (order.status === "succeeded") {
          // promo usage
          try {
            const usages = new Map();
            for (const it of order.items || []) {
              const code = it?.promo?.code;
              if (!code) continue;
              const q = Math.max(1, Number(it.qty) || 1);
              usages.set(code, (usages.get(code) || 0) + q);
            }
            if (usages.size > 0) {
              const ops = [];
              for (const [code, inc] of usages.entries()) {
                ops.push(
                  Promo.updateOne(
                    { code: String(code).toUpperCase(), deletedAt: null },
                    { $inc: { used: inc } }
                  ).catch(() => null)
                );
              }
              await Promise.allSettled(ops);
            }
          } catch (err) {
            console.warn(
              "[PROMO] increment usage in webhook(session):",
              err?.message || err
            );
          }

          // ✅ licences puis payouts
          await ensureLicensesForOrder(order._id);
          await ensurePayoutsForOrder(order);
        }
      }
    } else if (event.type === "checkout.session.expired") {
      const order = await Order.findOne({
        "stripe.checkoutSessionId": object.id,
      });
      if (order && order.status === "requires_payment") {
        order.status = "canceled";
        await order.save();
      }
    }
  } catch (e) {
    console.error(
      "[STRIPE][MARKETPLACE] webhook handler error:",
      e?.message || e
    );
  }
}

module.exports = { handleMarketplaceStripeEvent };
