// backend/src/routes/payments/features/marketplace/endpoints/refresh.js
const Stripe = require("stripe");
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2024-06-20",
});

const Order = require("../../../../../models/order.model");
const Promo = require("../../../../../models/promoCode.model");
const {
  ensurePayoutsForOrder,
} = require("../../../../../services/payouts.service");
const {
  ensureLicensesForOrder,
} = require("../../../../../services/licenses/ensureLicensesForOrder");
const { hydrateOrderFromStripe } = require("../stripe.hydrate");

// Helper: Incrémenter les promos une seule fois
async function incrementPromoUsage(order) {
  try {
    const usages = new Map();
    for (const it of order.items || []) {
      const code = it?.promo?.code;
      if (!code) continue;
      const q = Math.max(1, Number(it.qty) || 1);
      usages.set(code, (usages.get(code) || 0) + q);
    }

    if (usages.size > 0) {
      const ops = [];
      for (const [code, inc] of usages.entries()) {
        ops.push(
          Promo.updateOne(
            { code: String(code).toUpperCase(), deletedAt: null },
            { $inc: { used: inc } },
          ).catch(() => null),
        );
      }
      await Promise.allSettled(ops);
    }
  } catch (err) {
    console.warn("[PROMO] increment usage error:", err?.message || err);
  }
}

/**
 * POST /payments/refresh
 * Permet de vérifier si une commande est passée à "succeeded".
 */
module.exports = async function refreshOrder(req, res) {
  try {
    const userId = req?.auth?.userId;
    if (!userId) {
      return res.status(401).json({ ok: false, error: "Non autorisé" });
    }

    const { orderId, sessionId, paymentIntentId } = req.body || {};

    // 1. Retrouver la commande
    let order =
      (orderId &&
        (await Order.findOne({ _id: String(orderId), user: userId }))) ||
      (sessionId &&
        (await Order.findOne({
          "stripe.checkoutSessionId": String(sessionId),
          user: userId,
        }))) ||
      (paymentIntentId &&
        (await Order.findOne({
          "stripe.paymentIntentId": String(paymentIntentId),
          user: userId,
        })));

    if (!order) {
      return res.status(404).json({ ok: false, error: "Commande introuvable" });
    }

    // 2. Gestion CRYPTO MANUEL (Pas d'appel API, juste lecture BDD)
    if (order.crypto?.provider === "manual_crypto") {
      // L'admin met à jour le statut directement en BDD via le Dashboard.
      // Ici on renvoie juste l'état actuel.

      return res.status(200).json({
        ok: true,
        data: {
          order: {
            id: String(order._id),
            status: order.status, // "requires_payment" ou "succeeded"
            paidAt: order.paidAt ? order.paidAt.toISOString() : null,
            crypto: order.crypto,
          },
        },
      });
    }

    // 3. Gestion STRIPE (Appel API pour vérifier le statut)
    let session = null;
    let pi = null;

    const sid = String(sessionId || order?.stripe?.checkoutSessionId || "");
    if (sid) {
      try {
        session = await stripe.checkout.sessions.retrieve(sid, {
          expand: ["payment_intent", "customer_details"],
        });
      } catch (e) {
        console.warn("[STRIPE] refresh session error:", e?.message);
      }
    }

    const pid = String(paymentIntentId || order?.stripe?.paymentIntentId || "");
    if (pid) {
      try {
        pi = await stripe.paymentIntents.retrieve(pid, {
          expand: ["latest_charge", "payment_method"],
        });
      } catch (e) {
        console.warn("[STRIPE] refresh PI error:", e?.message);
      }
    }

    // Mise à jour de la commande avec les données Stripe
    await hydrateOrderFromStripe({ order, session, pi, stripe });
    await order.save();

    // 4. Actions Post-Paiement (Si succès confirmé)
    if (order.status === "succeeded") {
      // On s'assure que les promos ne sont incrémentées qu'une fois
      if (!order.promoApplied) {
        await incrementPromoUsage(order);
        order.promoApplied = true;
        await order.save();
      }

      await ensureLicensesForOrder(order._id);
      await ensurePayoutsForOrder(order);
    }

    return res.status(200).json({
      ok: true,
      data: {
        order: {
          id: String(order._id),
          status: order.status,
          paidAt: order.paidAt ? order.paidAt.toISOString() : null,
          stripe: order.stripe,
        },
      },
    });
  } catch (e) {
    console.error("[PAYMENTS] refresh error:", e?.stack || e);
    return res.status(500).json({ ok: false, error: "Refresh impossible" });
  }
};
