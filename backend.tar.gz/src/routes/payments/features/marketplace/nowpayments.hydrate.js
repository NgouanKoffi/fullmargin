// C:\Users\ADMIN\Desktop\fullmargin-site\backend\src\routes\payments\features\marketplace\nowpayments.hydrate.js
function normalizeOrderStatusFromNow(status) {
  if (status === "success") return "succeeded";
  if (status === "failed") return "failed";
  if (status === "canceled") return "canceled";
  return "requires_payment"; // pending
}

async function hydrateOrderFromNowpayments({ order, payment }) {
  try {
    const p = payment || {};
    const raw = p.raw || {};

    const invoiceId =
      raw.invoice_id || raw.id || order?.nowpayments?.invoiceId || null;

    const paymentId =
      raw.payment_id || raw.id || order?.nowpayments?.paymentId || null;

    const mappedStatus = normalizeOrderStatusFromNow(p.status);

    order.nowpayments = {
      ...(order.nowpayments || {}),
      provider: "nowpayments",
      providerEvent: p.providerEvent || null,
      invoiceId,
      paymentId,
      status: p.status || "pending",
      customerEmail:
        p.customerEmail || order?.nowpayments?.customerEmail || null,
      amounts: {
        currency: (p.currency || order.currency || "usd").toLowerCase(),
        amount: typeof p.amount === "number" ? p.amount : null,
      },
      // garde un raw MINIMAL (évite exploser la taille du doc)
      raw: {
        payment_status: raw.payment_status || raw.status || null,
        pay_amount: raw.pay_amount || raw.actually_paid || null,
        pay_currency: raw.pay_currency || null,
        price_amount: raw.price_amount || null,
        price_currency: raw.price_currency || null,
        invoice_url: raw.invoice_url || null,
      },
    };

    if (mappedStatus === "succeeded") {
      order.status = "succeeded";
      order.paidAt = order.paidAt || new Date();
    } else if (mappedStatus === "failed") {
      order.status = "failed";
    } else if (mappedStatus === "canceled") {
      order.status = "canceled";
    } else if (!["succeeded", "failed", "canceled"].includes(order.status)) {
      order.status = "requires_payment";
    }
  } catch (e) {
    console.warn(
      "[NOWPAYMENTS] hydrateOrderFromNowpayments error:",
      e?.message || e
    );
  }
}

module.exports = { hydrateOrderFromNowpayments };
