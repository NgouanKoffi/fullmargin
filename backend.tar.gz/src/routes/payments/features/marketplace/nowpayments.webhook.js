// C:\Users\ADMIN\Desktop\fullmargin-site\backend\src\routes\payments\features\marketplace\nowpayments.webhook.js
const Order = require("../../../../models/order.model");
const Promo = require("../../../../models/promoCode.model");
const {
  ensurePayoutsForOrder,
} = require("../../../../services/payouts.service");
const {
  ensureLicensesForOrder,
} = require("../../../../services/licenses/ensureLicensesForOrder");

const { hydrateOrderFromNowpayments } = require("./nowpayments.hydrate");

async function incrementPromoUsageOnce(order) {
  // ✅ évite double incrément si IPN "success" arrive plusieurs fois
  if (order?.nowpayments?.promoUsageApplied) return;

  try {
    const usages = new Map();
    for (const it of order.items || []) {
      const code = it?.promo?.code;
      if (!code) continue;
      const q = Math.max(1, Number(it.qty) || 1);
      usages.set(code, (usages.get(code) || 0) + q);
    }

    if (usages.size > 0) {
      const ops = [];
      for (const [code, inc] of usages.entries()) {
        ops.push(
          Promo.updateOne(
            { code: String(code).toUpperCase(), deletedAt: null },
            { $inc: { used: inc } }
          ).catch(() => null)
        );
      }
      await Promise.allSettled(ops);
    }

    order.nowpayments = {
      ...(order.nowpayments || {}),
      promoUsageApplied: true,
    };
    await order.save().catch(() => null);
  } catch (err) {
    console.warn(
      "[PROMO] increment usage in nowpayments:",
      err?.message || err
    );
  }
}

async function handleMarketplaceNowPaymentsPayment(payment) {
  const p = payment || {};
  if (p.provider !== "nowpayments") return;
  if (p.feature !== "marketplace") return;

  // ✅ orderId robuste (orderId / order_id / ref)
  const orderId =
    (p?.meta?.orderId && String(p.meta.orderId)) ||
    (p?.meta?.order_id && String(p.meta.order_id)) ||
    (p?.meta?.ref && String(p.meta.ref)) ||
    null;

  if (!orderId) return;

  try {
    const order = await Order.findById(orderId);
    if (!order) return;

    // hydrate
    await hydrateOrderFromNowpayments({ order, payment: p });
    await order.save();

    if (order.status === "succeeded") {
      await incrementPromoUsageOnce(order);
      await ensureLicensesForOrder(order._id);
      await ensurePayoutsForOrder(order);
    }
  } catch (e) {
    console.error("[NOWPAYMENTS][MARKETPLACE] handler error:", e?.message || e);
  }
}

module.exports = { handleMarketplaceNowPaymentsPayment };
