// backend/src/routes/payments/handlers/marketplace.handler.js
const Order = require("../../../models/order.model");
const Promo = require("../../../models/promoCode.model");
const User = require("../../../models/user.model");

// ✅ CORRECTION ICI : On remonte de 3 niveaux (../../../) pour atteindre src/utils
const Mailer = require("../../../utils/mailer");

const { ensurePayoutsForOrder } = require("../../../services/payouts.service");

// Helper pour le formatage monétaire dans le mail
const fmtMoney = (amount, currency) => {
  try {
    return new Intl.NumberFormat("fr-FR", {
      style: "currency",
      currency: currency || "USD",
    }).format(amount);
  } catch {
    return `${amount} ${currency}`;
  }
};

async function handleMarketplacePaymentEvent(payment) {
  try {
    const meta = payment?.meta || {};
    const orderId = meta.orderId || null;

    if (!orderId) {
      console.warn("[MARKET HANDLER] orderId manquant");
      return;
    }

    // On charge la commande et l'acheteur (pour avoir son nom dans le mail vendeur)
    const order = await Order.findById(orderId).populate(
      "user",
      "name email profile",
    );
    if (!order) {
      console.warn("[MARKET HANDLER] Order non trouvée:", orderId);
      return;
    }

    // ✅ idempotence: si déjà payé, on arrête (évite double emails)
    if (order.status === "succeeded") {
      return;
    }

    // ---- ROUTAGE SELON STATUS ----
    switch (payment.status) {
      case "success": {
        order.status = "succeeded";
        order.paidAt = order.paidAt || new Date();
        await order.save();

        // 1. Incrémenter les codes promo
        try {
          const usages = new Map();
          for (const item of order.items || []) {
            const code = item?.promo?.code;
            if (!code) continue;
            const qty = Math.max(1, Number(item.qty) || 1);
            usages.set(code, (usages.get(code) || 0) + qty);
          }

          for (const [code, inc] of usages.entries()) {
            await Promo.updateOne(
              { code: String(code).toUpperCase(), deletedAt: null },
              { $inc: { used: inc } },
            );
          }
        } catch (promoErr) {
          console.warn("[MARKET HANDLER] promo error:", promoErr);
        }

        // 2. Générer les payouts (commissions vendeur)
        await ensurePayoutsForOrder(order);

        // 3. ✅ ENVOYER NOTIFICATION AUX VENDEURS
        try {
          // A. On groupe les items par vendeur
          const sellerMap = new Map(); // sellerId -> { items: [], total: 0 }

          for (const item of order.items) {
            const sid = String(item.seller);
            if (!sellerMap.has(sid)) {
              sellerMap.set(sid, { items: [], total: 0 });
            }

            const entry = sellerMap.get(sid);
            const lineTotal = (item.unitAmount || 0) * (item.qty || 1);

            entry.items.push({
              title: item.title,
              qty: item.qty,
              amount: fmtMoney(lineTotal, order.currency),
            });
            entry.total += lineTotal;
          }

          // B. On récupère les emails des vendeurs concernés
          const sellerIds = Array.from(sellerMap.keys());
          if (sellerIds.length > 0) {
            const sellers = await User.find({ _id: { $in: sellerIds } }).select(
              "email name profile",
            );
            const buyerName =
              order.user?.profile?.fullName || order.user?.name || "Un client";

            // C. On envoie un email à chaque vendeur
            for (const sellerUser of sellers) {
              const data = sellerMap.get(String(sellerUser._id));
              if (!data || !sellerUser.email) continue;

              await Mailer.sendMarketplaceSaleNotificationEmail({
                to: sellerUser.email,
                fullName: sellerUser.profile?.fullName || sellerUser.name,
                customerName: buyerName,
                items: data.items,
                totalEarnings: fmtMoney(data.total, order.currency),
              });

              console.log(
                `[Marketplace] ✉️ Notification vente envoyée au vendeur ${sellerUser.email}`,
              );
            }
          }
        } catch (mailErr) {
          console.error("[MARKET HANDLER] mail sellers error:", mailErr);
        }

        break;
      }

      case "failed":
      case "canceled": {
        order.status = payment.status;
        await order.save();
        break;
      }

      default:
        console.log("[MARKET HANDLER] status ignoré:", payment.status);
    }
  } catch (err) {
    console.error("[MARKET HANDLER] error:", err);
  }
}

module.exports = { handleMarketplacePaymentEvent };
