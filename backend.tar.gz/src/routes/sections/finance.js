// backend/src/routes/sections/finance.js
const crypto = require("node:crypto");
const mongoose = require("mongoose");
const Withdrawal = require("../../models/withdrawal.model"); // ✅ doit exporter le model (pas s'auto-require)
const User = require("../../models/user.model");
const { requireAuth } = require("../../middlewares/auth");

/* ===== UTILITAIRES ===== */
const clampStr = (v, max) =>
  String(v || "")
    .trim()
    .slice(0, max);

const toISO = (d) => {
  try {
    const x = d instanceof Date ? d : new Date(d);
    return x.toISOString();
  } catch {
    return "";
  }
};

const money = (val) => Number(Number(val || 0).toFixed(2));

const escapeRegex = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const generateReference = () => {
  const date = new Date().toISOString().slice(0, 7).replace("-", "");
  const random = Math.random().toString(36).substring(2, 7).toUpperCase();
  return `W-${date}-${random}`;
};

const MIN_WITHDRAW_AMOUNT = 100;
const COMMISSION_RATE = 0.0999;

const TX_UNSUPPORTED = (e) => {
  const msg = String(e?.message || "");
  return (
    msg.includes("Transaction numbers are only allowed") ||
    msg.includes("replica set") ||
    msg.includes("mongos")
  );
};

/* ===== ADMIN / AGENT GUARD ===== */
async function requireAdminOrAgent(req, res, next) {
  try {
    const userId = req?.auth?.userId;
    if (!userId)
      return res.status(401).json({ ok: false, error: "Non autorisé" });

    const me = await User.findById(userId).select("roles").lean();
    const roles = me?.roles || [];
    if (!roles.includes("admin") && !roles.includes("agent")) {
      return res.status(403).json({ ok: false, error: "Accès refusé" });
    }
    next();
  } catch {
    return res.status(401).json({ ok: false, error: "Non autorisé" });
  }
}

/* ===== RESTORE FUNDS (idempotent) =====
   - utilise w.frozen (snapshot au moment du retrait)
   - protège contre double restauration via restoredAt
*/
async function restoreFunds(withdrawalId, note, actorId) {
  const session = await mongoose.startSession();

  try {
    session.startTransaction();

    const w = await Withdrawal.findById(withdrawalId).session(session);
    if (!w) throw new Error("Withdrawal not found");

    if (w.restoredAt) {
      await session.commitTransaction();
      return { ok: true, already: true };
    }

    const frozen = w.frozen || {};
    const inc = {
      sellerBalance: Number(frozen.seller || 0),
      communityBalance: Number(frozen.community || 0),
      affiliationBalance: Number(frozen.affiliation || 0),
    };

    await User.updateOne({ _id: w.user }, { $inc: inc }, { session });

    await Withdrawal.updateOne(
      { _id: w._id, restoredAt: null },
      {
        $set: {
          restoredAt: new Date(),
          restoredBy: actorId || null, // si ton schema ne l'a pas, ce champ sera ignoré (mode strict)
          adminNote: note ? String(note) : w.adminNote || "",
          processedAt: new Date(),
        },
      },
      { session },
    );

    await session.commitTransaction();
    return { ok: true };
  } catch (e) {
    try {
      await session.abortTransaction();
    } catch {}

    // Fallback sans transaction
    const w = await Withdrawal.findById(withdrawalId);
    if (!w) throw e;
    if (w.restoredAt) return { ok: true, already: true };

    const frozen = w.frozen || {};
    await User.updateOne(
      { _id: w.user },
      {
        $inc: {
          sellerBalance: Number(frozen.seller || 0),
          communityBalance: Number(frozen.community || 0),
          affiliationBalance: Number(frozen.affiliation || 0),
        },
      },
    );

    await Withdrawal.updateOne(
      { _id: w._id, restoredAt: null },
      {
        $set: {
          restoredAt: new Date(),
          restoredBy: actorId || null,
          adminNote: note || "",
          processedAt: new Date(),
        },
      },
    );

    return { ok: true, fallback: true };
  } finally {
    session.endSession();
  }
}

module.exports = (router) => {
  /* =========================================================
     1) USER — CRÉER UNE DEMANDE DE RETRAIT
     POST /wallet/withdrawals
  ========================================================= */
  router.post("/wallet/withdrawals", requireAuth, async (req, res) => {
    const rid = req._rid || crypto.randomUUID();
    const t0 = Date.now();

    try {
      const userId = req.auth.userId;
      const b = req.body || {};

      // --- Validation méthode ---
      const method = String(b.method || "")
        .trim()
        .toUpperCase();
      if (!["USDT", "BTC", "BANK"].includes(method)) {
        return res.status(400).json({ ok: false, error: "Méthode invalide" });
      }

      // --- Validation détails paiement ---
      const details = b.paymentDetails || {};
      const paymentDetails = {
        cryptoAddress: clampStr(details.cryptoAddress, 200),
        bankName: clampStr(details.bankName, 100),
        bankIban: clampStr(details.bankIban, 50),
        bankSwift: clampStr(details.bankSwift, 20),
        bankCountry: clampStr(details.bankCountry, 50),
      };

      if (method === "BANK") {
        if (
          !paymentDetails.bankName ||
          !paymentDetails.bankIban ||
          !paymentDetails.bankCountry
        ) {
          return res.status(400).json({
            ok: false,
            error:
              "Informations bancaires incomplètes (Nom, IBAN/RIB, Pays requis).",
          });
        }
      } else {
        if (!paymentDetails.cryptoAddress) {
          return res
            .status(400)
            .json({ ok: false, error: "Adresse crypto requise." });
        }
      }

      // --- Anti-doublon : pas de retrait actif ---
      const active = await Withdrawal.findOne({
        user: userId,
        status: { $in: ["PENDING", "VALIDATED"] },
      }).lean();
      if (active) {
        return res
          .status(400)
          .json({ ok: false, error: "Un retrait est déjà en cours." });
      }

      // ✅ tentative transaction (si ReplicaSet)
      const session = await mongoose.startSession();
      try {
        session.startTransaction();

        const user = await User.findById(userId).session(session);
        if (!user) {
          await session.abortTransaction();
          return res
            .status(404)
            .json({ ok: false, error: "Utilisateur introuvable" });
        }

        const s1 = Number(user.sellerBalance || 0);
        const s2 = Number(user.communityBalance || 0);
        const s3 = Number(user.affiliationBalance || 0);
        const totalBalance = money(s1 + s2 + s3);

        if (totalBalance < MIN_WITHDRAW_AMOUNT) {
          await session.abortTransaction();
          return res.status(400).json({
            ok: false,
            error: `Solde insuffisant (${totalBalance}$ détecté, minimum ${MIN_WITHDRAW_AMOUNT}$).`,
          });
        }

        const commission = money(totalBalance * COMMISSION_RATE);
        const amountNet = money(totalBalance - commission);

        let created;
        try {
          created = await Withdrawal.create(
            [
              {
                user: userId,
                reference: generateReference(),
                amountGross: totalBalance,
                commission,
                amountNet,
                method,
                paymentDetails,
                status: "PENDING",

                // ✅ snapshot gelé (utilisé pour restore)
                frozen: {
                  seller: money(s1),
                  community: money(s2),
                  affiliation: money(s3),
                },

                restoredAt: null,
                processedAt: null,
              },
            ],
            { session },
          );
        } catch (e) {
          if (e && e.code === 11000) {
            await session.abortTransaction();
            return res
              .status(409)
              .json({ ok: false, error: "Conflit de référence. Réessayez." });
          }
          throw e;
        }

        // gel des fonds
        user.sellerBalance = 0;
        user.communityBalance = 0;
        user.affiliationBalance = 0;
        await user.save({ session });

        await session.commitTransaction();

        const w = created[0];
        return res.status(201).json({
          ok: true,
          data: {
            id: String(w._id),
            reference: w.reference,
            amountGross: w.amountGross,
            commission: w.commission,
            amountNet: w.amountNet,
            status: w.status,
            createdAt: toISO(w.createdAt),
          },
        });
      } catch (e) {
        try {
          await session.abortTransaction();
        } catch {}

        // ✅ fallback si les transactions ne sont pas supportées
        if (!TX_UNSUPPORTED(e)) throw e;

        // atomic freeze (findOneAndUpdate new:false => on récupère l'ancien solde)
        const userBefore = await User.findOneAndUpdate(
          { _id: userId },
          {
            $set: {
              sellerBalance: 0,
              communityBalance: 0,
              affiliationBalance: 0,
            },
          },
          { new: false },
        );

        if (!userBefore) {
          return res
            .status(404)
            .json({ ok: false, error: "Utilisateur introuvable" });
        }

        const s1 = Number(userBefore.sellerBalance || 0);
        const s2 = Number(userBefore.communityBalance || 0);
        const s3 = Number(userBefore.affiliationBalance || 0);
        const totalBalance = money(s1 + s2 + s3);

        if (totalBalance < MIN_WITHDRAW_AMOUNT) {
          // restore immediate (on remet comme avant)
          await User.updateOne(
            { _id: userId },
            {
              $set: {
                sellerBalance: s1,
                communityBalance: s2,
                affiliationBalance: s3,
              },
            },
          );
          return res.status(400).json({
            ok: false,
            error: `Solde insuffisant (${totalBalance}$ détecté, minimum ${MIN_WITHDRAW_AMOUNT}$).`,
          });
        }

        const commission = money(totalBalance * COMMISSION_RATE);
        const amountNet = money(totalBalance - commission);

        try {
          const w = await Withdrawal.create({
            user: userId,
            reference: generateReference(),
            amountGross: totalBalance,
            commission,
            amountNet,
            method,
            paymentDetails,
            status: "PENDING",
            frozen: {
              seller: money(s1),
              community: money(s2),
              affiliation: money(s3),
            },
            restoredAt: null,
            processedAt: null,
          });

          return res.status(201).json({
            ok: true,
            data: {
              id: String(w._id),
              reference: w.reference,
              amountGross: w.amountGross,
              commission: w.commission,
              amountNet: w.amountNet,
              status: w.status,
              createdAt: toISO(w.createdAt),
            },
          });
        } catch (err) {
          // si création échoue => on restaure l'argent
          await User.updateOne(
            { _id: userId },
            {
              $set: {
                sellerBalance: s1,
                communityBalance: s2,
                affiliationBalance: s3,
              },
            },
          );

          if (err && err.code === 11000) {
            return res
              .status(409)
              .json({ ok: false, error: "Conflit de référence. Réessayez." });
          }
          throw err;
        }
      } finally {
        session.endSession();
        // log
        console.log(
          `[FINANCE ${rid}] POST /wallet/withdrawals done (${Date.now() - t0}ms)`,
        );
      }
    } catch (e) {
      console.error(`[FINANCE] ERROR:`, e?.stack || e);
      return res
        .status(500)
        .json({ ok: false, error: "Erreur serveur lors du retrait" });
    }
  });

  /* =========================================================
     2) USER — HISTORIQUE
     GET /wallet/withdrawals
  ========================================================= */
  router.get("/wallet/withdrawals", requireAuth, async (req, res) => {
    try {
      const userId = req.auth.userId;
      const rows = await Withdrawal.find({ user: userId })
        .sort({ createdAt: -1 })
        .lean();

      const items = rows.map((w) => ({
        id: String(w._id),
        reference: w.reference,
        date: toISO(w.createdAt),
        amount: w.amountNet,
        amountGross: w.amountGross,
        method: w.method,
        details:
          w.method === "BANK"
            ? w.paymentDetails?.bankIban || ""
            : w.paymentDetails?.cryptoAddress || "",
        // ✅ renvoie les statuts complets
        status: w.status,
        invoiceUrl: w.invoiceUrl || null,
        payoutRef: w.payoutRef || w.transactionId || null,
        rejectionReason: w.rejectionReason || null,
        failureReason: w.failureReason || null,
        adminNote: w.adminNote || "",
      }));

      return res.status(200).json({ ok: true, data: items });
    } catch {
      return res.status(500).json({ ok: false, error: "Erreur historique" });
    }
  });

  /* =========================================================
     3) DEV ONLY — DEBUG REFILL
  ========================================================= */
  router.get("/wallet/debug-refill", requireAuth, async (req, res) => {
    try {
      if (process.env.NODE_ENV === "production") {
        return res.status(404).json({ ok: false, error: "Not found" });
      }

      const userId = req.auth.userId;
      await User.findByIdAndUpdate(userId, {
        sellerBalance: 215,
        communityBalance: 0,
        affiliationBalance: 0,
      });

      return res.json({ ok: true, message: "Wallet crédité à 215$ (DEV)." });
    } catch (e) {
      return res.status(500).json({ ok: false, error: e.message });
    }
  });

  /* =========================================================
     4) ADMIN — LISTE DES RETRAITS
     GET /admin/withdrawals?status=PENDING&q=...
     (⚠️ match ton frontend /admin/withdrawals)
  ========================================================= */
  router.get(
    "/admin/withdrawals",
    requireAuth,
    requireAdminOrAgent,
    async (req, res) => {
      try {
        const page = Math.max(parseInt(String(req.query.page || "1"), 10), 1);
        const limit = Math.min(
          50,
          Math.max(parseInt(String(req.query.limit || "200"), 10), 1),
        );
        const skip = (page - 1) * limit;

        const status = String(req.query.status || "")
          .trim()
          .toUpperCase();
        const q = String(req.query.q || "").trim();

        const match = {};
        if (
          ["PENDING", "VALIDATED", "REJECTED", "PAID", "FAILED"].includes(
            status,
          )
        ) {
          match.status = status;
        }

        if (q) {
          const rx = new RegExp(escapeRegex(q), "i");
          const users = await User.find({
            $or: [
              { email: rx },
              { fullName: rx },
              { displayName: rx },
              { name: rx },
            ],
          })
            .select("_id")
            .lean();

          const userIds = users.map((u) => u._id);
          match.$or = [
            { reference: rx },
            ...(userIds.length ? [{ user: { $in: userIds } }] : []),
          ];
        }

        const [rows, total] = await Promise.all([
          Withdrawal.find(match)
            .populate("user", "email fullName displayName name")
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit)
            .lean(),
          Withdrawal.countDocuments(match),
        ]);

        const items = rows.map((w) => ({
          id: String(w._id),
          reference: w.reference,
          currency: "USD",
          amountGross: w.amountGross,
          commission: w.commission,
          amountNet: w.amountNet,
          method: w.method,
          status: w.status,
          createdAt: toISO(w.createdAt),
          processedAt: w.processedAt ? toISO(w.processedAt) : null,
          payoutRef: w.payoutRef || w.transactionId || "",
          rejectionReason: w.rejectionReason || "",
          failureReason: w.failureReason || "",
          adminNote: w.adminNote || "",
          user: w.user
            ? {
                id: String(w.user._id),
                email: w.user.email || "",
                name:
                  w.user.fullName ||
                  w.user.displayName ||
                  w.user.name ||
                  (w.user.email ? String(w.user.email).split("@")[0] : "User"),
              }
            : null,
        }));

        return res.json({
          ok: true,
          data: {
            items,
            page,
            limit,
            total,
            hasMore: skip + items.length < total,
          },
        });
      } catch (e) {
        console.error("[ADMIN withdrawals] ERROR:", e?.stack || e);
        return res.status(500).json({ ok: false, error: "Lecture impossible" });
      }
    },
  );

  /* =========================================================
     5) ADMIN — VALIDER
     POST /admin/withdrawals/:id/validate
  ========================================================= */
  router.post(
    "/admin/withdrawals/:id/validate",
    requireAuth,
    requireAdminOrAgent,
    async (req, res) => {
      try {
        const id = String(req.params.id);
        const note = clampStr(req.body?.note, 200);

        const w = await Withdrawal.findById(id);
        if (!w)
          return res.status(404).json({ ok: false, error: "Introuvable" });
        if (w.status !== "PENDING") {
          return res
            .status(400)
            .json({ ok: false, error: "Statut non éligible" });
        }

        w.status = "VALIDATED";
        w.processedAt = new Date();
        w.adminNote = note || w.adminNote || "";
        w.validatedBy = req.auth.userId;
        w.rejectionReason = null;
        w.failureReason = null;
        await w.save();

        return res.json({ ok: true });
      } catch (e) {
        console.error("[ADMIN validate] ERROR:", e?.stack || e);
        return res.status(500).json({ ok: false, error: "Action impossible" });
      }
    },
  );

  /* =========================================================
     6) ADMIN — REJETER (RESTORE)
     POST /admin/withdrawals/:id/reject  body: { reason }
  ========================================================= */
  router.post(
    "/admin/withdrawals/:id/reject",
    requireAuth,
    requireAdminOrAgent,
    async (req, res) => {
      try {
        const id = String(req.params.id);
        const reason = clampStr(req.body?.reason, 300);
        if (!reason) {
          return res
            .status(400)
            .json({ ok: false, error: "Motif obligatoire" });
        }

        const w = await Withdrawal.findById(id);
        if (!w)
          return res.status(404).json({ ok: false, error: "Introuvable" });
        if (!["PENDING", "VALIDATED"].includes(w.status)) {
          return res
            .status(400)
            .json({ ok: false, error: "Statut non éligible" });
        }

        w.status = "REJECTED";
        w.processedAt = new Date();
        w.adminNote = reason;
        w.rejectionReason = reason;
        w.rejectedBy = req.auth.userId;
        await w.save();

        await restoreFunds(id, reason, req.auth.userId);

        return res.json({ ok: true });
      } catch (e) {
        console.error("[ADMIN reject] ERROR:", e?.stack || e);
        return res.status(500).json({ ok: false, error: "Action impossible" });
      }
    },
  );

  /* =========================================================
     7) ADMIN — MARQUER PAYÉ
     POST /admin/withdrawals/:id/mark-paid  body: { payoutRef }
  ========================================================= */
  router.post(
    "/admin/withdrawals/:id/mark-paid",
    requireAuth,
    requireAdminOrAgent,
    async (req, res) => {
      try {
        const id = String(req.params.id);
        const payoutRef = clampStr(req.body?.payoutRef, 200);
        if (!payoutRef) {
          return res
            .status(400)
            .json({ ok: false, error: "Référence paiement requise" });
        }

        const w = await Withdrawal.findById(id);
        if (!w)
          return res.status(404).json({ ok: false, error: "Introuvable" });
        if (w.status !== "VALIDATED") {
          return res
            .status(400)
            .json({ ok: false, error: "Statut non éligible" });
        }

        w.status = "PAID";
        w.processedAt = new Date();
        w.payoutRef = payoutRef;
        w.transactionId = payoutRef; // compat si tu avais déjà ce champ
        w.paidBy = req.auth.userId;
        await w.save();

        return res.json({ ok: true });
      } catch (e) {
        console.error("[ADMIN mark-paid] ERROR:", e?.stack || e);
        return res.status(500).json({ ok: false, error: "Action impossible" });
      }
    },
  );

  /* =========================================================
     8) ADMIN — MARQUER ÉCHEC (RESTORE)
     POST /admin/withdrawals/:id/mark-failed  body: { reason }
  ========================================================= */
  router.post(
    "/admin/withdrawals/:id/mark-failed",
    requireAuth,
    requireAdminOrAgent,
    async (req, res) => {
      try {
        const id = String(req.params.id);
        const reason = clampStr(req.body?.reason, 300);
        if (!reason) {
          return res
            .status(400)
            .json({ ok: false, error: "Motif obligatoire" });
        }

        const w = await Withdrawal.findById(id);
        if (!w)
          return res.status(404).json({ ok: false, error: "Introuvable" });
        if (w.status !== "VALIDATED") {
          return res
            .status(400)
            .json({ ok: false, error: "Statut non éligible" });
        }

        w.status = "FAILED";
        w.processedAt = new Date();
        w.adminNote = reason;
        w.failureReason = reason;
        w.failedBy = req.auth.userId;
        await w.save();

        await restoreFunds(id, reason, req.auth.userId);

        return res.json({ ok: true });
      } catch (e) {
        console.error("[ADMIN mark-failed] ERROR:", e?.stack || e);
        return res.status(500).json({ ok: false, error: "Action impossible" });
      }
    },
  );
};
