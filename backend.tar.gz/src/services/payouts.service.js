// C:\Users\ADMIN\Desktop\fullmargin-site\backend\src\services\payouts.service.js
const Product = require("../models/product.model");
const Category = require("../models/category.model");
const SellerPayout = require("../models/sellerPayout.model");
const AdminCommission = require("../models/adminCommission.model");

const toCents = (usd) => Math.round(Number(usd || 0) * 100);
const toUnits = (cents) => Math.round(Number(cents || 0)) / 100;

/* ------------------------------------------------------------------
   Commission % par produit/catégorie, avec fallback environnemental.
   - COMMISSION_PCT_DEFAULT ou MARKETPLACE_COMMISSION_PCT (ex: "20")
------------------------------------------------------------------- */
const DEFAULT_PCT = Number(
  process.env.MARKETPLACE_COMMISSION_PCT ??
    process.env.COMMISSION_PCT_DEFAULT ??
    20
);

async function getCommissionPctForProduct({ category }) {
  try {
    if (category) {
      // D’abord via la clé de catégorie
      let cat =
        (await Category.findOne({ key: String(category) })
          .select("commissionPct parent")
          .lean()) || null;

      // Si non trouvée par key, on tente l’_id
      if (!cat) {
        cat =
          (await Category.findOne({ _id: String(category) })
            .select("commissionPct parent")
            .lean()) || null;
      }

      if (cat) {
        if (typeof cat.commissionPct === "number") {
          return Math.max(0, Number(cat.commissionPct));
        }
        // Fallback sur le parent si défini
        if (cat.parent) {
          const parent = await Category.findById(cat.parent)
            .select("commissionPct")
            .lean();
          if (parent && typeof parent.commissionPct === "number") {
            return Math.max(0, Number(parent.commissionPct));
          }
        }
      }
    }
  } catch (e) {
    console.warn("[commission] lookup error:", e?.message || e);
  }
  return Math.max(0, DEFAULT_PCT);
}

/* ------------------------------------------------------------------
   Crée/Met à jour les payouts & commissions admin pour une commande
   - Idempotent (index unique côté modèles)
------------------------------------------------------------------- */
async function ensurePayoutsForOrder(orderOrId) {
  const Order = require("../models/order.model");

  // Normalise l’input en document lean()
  const order =
    typeof orderOrId === "string"
      ? await Order.findById(orderOrId).lean()
      : orderOrId?.toObject?.() || orderOrId;

  if (!order) return;
  if (order.status !== "succeeded") return;

  const currency = String(order.currency || "usd").toLowerCase();
  const buyerId = order.user;

  const pctCache = new Map(); // categoryKey -> pct

  for (const it of order.items || []) {
    try {
      // Pré-remplis depuis l’item
      let sellerId = it.seller || null;
      let shopId = it.shop || null;
      let categoryKey = null;

      // On lit le produit si besoin (catégorie, vendeur manquant, etc.)
      if (!sellerId || categoryKey == null) {
        const product = await Product.findById(it.product)
          .select("_id user shop category")
          .lean();
        if (product) {
          sellerId = sellerId || product.user;
          shopId = shopId || product.shop || null;
          categoryKey = product.category ?? null;
        }
      }

      // Commission %
      let pct =
        categoryKey != null && pctCache.has(categoryKey)
          ? pctCache.get(categoryKey)
          : await getCommissionPctForProduct({ category: categoryKey });
      if (categoryKey != null) pctCache.set(categoryKey, pct);

      const qty = Math.max(1, Number(it.qty) || 1);
      const unitAmountCents = toCents(it.unitAmount);
      const grossAmountCents = unitAmountCents * qty;
      const commissionAmountCents = Math.round((grossAmountCents * pct) / 100);
      const netAmountCents = grossAmountCents - commissionAmountCents;

      // 🧾 côté vendeur (idempotent)
      await SellerPayout.findOneAndUpdate(
        { order: order._id, product: it.product, seller: sellerId },
        {
          $set: {
            shop: shopId || null,
            buyer: buyerId,
            qty,
            currency,
            commissionRate: pct,
            unitAmountCents,
            grossAmountCents,
            commissionAmountCents,
            netAmountCents,
            unitAmount: toUnits(unitAmountCents),
            grossAmount: toUnits(grossAmountCents),
            commissionAmount: toUnits(commissionAmountCents),
            netAmount: toUnits(netAmountCents),
            status: "available",
          },
        },
        { upsert: true, new: true, setDefaultsOnInsert: true }
      );

      // 🏛️ côté admin (idempotent)
      await AdminCommission.findOneAndUpdate(
        { order: order._id, product: it.product },
        {
          $set: {
            seller: sellerId,
            buyer: buyerId,
            shop: shopId || null,
            qty,
            currency,
            commissionRate: pct,
            commissionAmountCents,
            commissionAmount: toUnits(commissionAmountCents),
          },
        },
        { upsert: true, new: true, setDefaultsOnInsert: true }
      );
    } catch (e) {
      console.error("[payouts] line error:", e?.stack || e);
    }
  }
}

module.exports = { ensurePayoutsForOrder };
