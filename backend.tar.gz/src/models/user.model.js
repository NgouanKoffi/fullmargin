// backend/src/models/user.model.js
const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    fullName: { type: String, required: true, trim: true },

    email: {
      type: String,
      required: true,
      lowercase: true,
      trim: true,
      // ❌ pas de unique/index ici, on centralise plus bas
    },

    // 🔒 Masqué par défaut
    passwordHash: { type: String, required: true, select: false },

    // 🖼️ URLs d'images (hébergées sur Cloudinary)
    avatarUrl: { type: String, default: "" },
    coverUrl: { type: String, default: "" },

    roles: { type: [String], default: ["user"] },
    isActive: { type: Boolean, default: true },

    // ⚙️ Contrôle des méthodes d'auth
    localEnabled: { type: Boolean, default: false },

    // 🔗 OAuth Google
    googleId: {
      type: String,
      trim: true,
      // ❌ pas d'index/sparse ici (on gère plus bas)
    },

    // 🔐 2FA
    twoFAEnabled: { type: Boolean, default: true },

    // 🧩 Affiliation
    referralCode: {
      type: String,
      trim: true,
      // ❌ pas de unique/sparse/index ici
      // ⚠️ ne pas mettre default: null pour bénéficier du sparse correctement
    },

    referredBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
      // ❌ pas d'index ici
    },
  },
  {
    timestamps: true,
    toJSON: {
      transform(doc, ret) {
        ret.id = String(ret._id);
        delete ret._id;
        delete ret.__v;
        delete ret.passwordHash;
        return ret;
      },
    },
    toObject: {
      transform(doc, ret) {
        ret.id = String(ret._id);
        delete ret._id;
        delete ret.__v;
        delete ret.passwordHash;
        return ret;
      },
    },
  }
);

/* ===== Index centralisés (une seule source de vérité) ===== */
userSchema.index({ email: 1 }, { unique: true, name: "u_email" });
// Si tu veux garantir qu’un googleId n’apparaisse qu’une fois, passe unique:true ; sinon laisse simple index
userSchema.index({ googleId: 1 }, { sparse: true, name: "u_googleId" });
userSchema.index(
  { referralCode: 1 },
  { unique: true, sparse: true, name: "u_referralCode" }
);
userSchema.index({ referredBy: 1 }, { name: "u_referredBy" });

module.exports = mongoose.model("User", userSchema);
