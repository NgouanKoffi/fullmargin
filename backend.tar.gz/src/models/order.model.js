// backend/src/models/order.model.js
const mongoose = require("mongoose");
const { Schema, model } = mongoose;

/* --------- Promo appliquée sur la ligne --------- */
const OrderItemPromoSchema = new Schema(
  {
    code: { type: String, required: true, uppercase: true, trim: true }, // ex: WELCOME10
    scope: {
      type: String,
      enum: ["global", "category", "product", "shop"],
      required: true,
    },
    type: { type: String, enum: ["percent", "amount"], required: true },
    value: { type: Number, min: 1, required: true }, // % ou montant fixe en USD
    discountUnit: { type: Number, min: 0, required: true }, // remise unitaire appliquée (USD)
    finalUnit: { type: Number, min: 0, required: true }, // prix unitaire après remise (USD)
  },
  { _id: false },
);

const OrderItemSchema = new Schema(
  {
    product: { type: Schema.Types.ObjectId, ref: "Product", required: true },
    title: { type: String, required: true },

    // Prix unitaire payé (USD) — déjà remisé si promo
    unitAmount: { type: Number, required: true, min: 0 },

    qty: { type: Number, required: true, min: 1 },

    // Qui vend cette ligne ?
    seller: { type: Schema.Types.ObjectId, ref: "User", required: true },
    shop: { type: Schema.Types.ObjectId, ref: "Shop", default: null },

    // 🆕 Trace de la promo appliquée sur cette ligne (si existante)
    promo: { type: OrderItemPromoSchema, default: undefined },
  },
  { _id: false },
);

/* --------- Stripe meta enrichi --------- */
const StripeAmountsSchema = new Schema(
  {
    currency: { type: String, default: "usd" },
    amount: { type: Number, default: null }, // unité (ex: 12.34)
    amountCents: { type: Number, default: null }, // cents (ex: 1234)
    fee: { type: Number, default: null }, // unité
    feeCents: { type: Number, default: null }, // cents
    net: { type: Number, default: null }, // unité
    netCents: { type: Number, default: null }, // cents
  },
  { _id: false },
);

const StripePaymentMethodSchema = new Schema(
  {
    type: { type: String, default: null }, // 'card', ...
    brand: { type: String, default: null }, // 'visa', ...
    last4: { type: String, default: null },
    expMonth: { type: Number, default: null },
    expYear: { type: Number, default: null },
  },
  { _id: false },
);

const StripeInfoSchema = new Schema(
  {
    paymentIntentId: { type: String, default: "" },
    clientSecret: { type: String, default: "" },
    checkoutSessionId: { type: String, default: "" },

    // Enrichissements utiles
    chargeId: { type: String, default: "" },
    receiptUrl: { type: String, default: "" },
    customerEmail: { type: String, default: "" },
    paymentMethod: { type: StripePaymentMethodSchema, default: () => ({}) },
    amounts: { type: StripeAmountsSchema, default: () => ({}) },
  },
  { _id: false },
);

/* --------- Crypto (validation manuelle admin) --------- */
const CryptoInfoSchema = new Schema(
  {
    network: { type: String, default: "" }, // ex: TRON, ERC20, BTC...
    txHash: { type: String, default: "" }, // hash transaction
    address: { type: String, default: "" }, // adresse de paiement (si utile)
    note: { type: String, default: "" },

    // audit validation admin
    validatedAt: { type: Date, default: null },
    validatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },

    rejectedAt: { type: Date, default: null },
    rejectedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    rejectionReason: { type: String, default: "" },
  },
  { _id: false },
);

const OrderSchema = new Schema(
  {
    // Acheteur
    user: { type: Schema.Types.ObjectId, ref: "User", required: true },

    items: { type: [OrderItemSchema], required: true },

    // Vendeurs et shops impliqués (dédupliqués)
    sellers: [
      { type: Schema.Types.ObjectId, ref: "User", index: true, default: [] },
    ],
    shops: [
      { type: Schema.Types.ObjectId, ref: "Shop", index: true, default: [] },
    ],

    currency: { type: String, default: "usd" },

    // Totaux de commande (après remises)
    totalAmount: { type: Number, required: true, min: 0 }, // dollars (affichage)
    totalAmountCents: { type: Number, required: true, min: 0 }, // cents

    // ✅ Distinction du provider (important pour filtrer "pending crypto")
    // ex: "stripe" | "crypto"
    provider: { type: String, default: "stripe", index: true },

    // ✅ Référence externe (crypto invoiceId / txHash / ref provider)
    paymentReference: { type: String, default: "", index: true },

    status: {
      type: String,
      enum: ["requires_payment", "succeeded", "canceled", "failed"],
      default: "requires_payment",
      index: true,
    },

    stripe: { type: StripeInfoSchema, default: () => ({}) },

    // ✅ crypto info (si provider=crypto)
    crypto: { type: CryptoInfoSchema, default: () => ({}) },

    paidAt: { type: Date, default: null },
    deletedAt: { type: Date, default: null },
  },
  { timestamps: true },
);

// Index utiles
OrderSchema.index(
  { user: 1, createdAt: -1 },
  { name: "ord_user_created_desc" },
);
OrderSchema.index({ "items.product": 1 }, { name: "ord_items_product" });
OrderSchema.index({ "items.seller": 1 }, { name: "ord_items_seller" });

// (optionnel) pour analytics promo
OrderSchema.index(
  { "items.promo.code": 1, createdAt: -1 },
  { name: "ord_items_promo_code_created" },
);

module.exports = model("Order", OrderSchema);
