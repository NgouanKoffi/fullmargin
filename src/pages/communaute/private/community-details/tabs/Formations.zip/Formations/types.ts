// src/pages/communaute/private/community-details/tabs/Formations/types.ts
export type Level = "Tous niveaux" | "Débutant" | "Intermédiaire" | "Avancé";

/** Miroir sérialisé d'un fichier */
export type MirrorFile = {
  name: string;
  type: string;
  lastModified: number;
  dataUrl: string;
};

export type CurriculumItem = {
  id: string;
  type: "video" | "pdf";
  title: string;
  file?: File | null;
  __serializedFile?: MirrorFile | null;
  url?: string | null;
  filename?: string | null;
  durationMin?: number;
};

export type Lesson = {
  id: string;
  title: string;
  /** Description de la leçon */
  description?: string;
  items: CurriculumItem[];
};

export type Module = {
  id: string;
  title: string;
  /** Description du module */
  description?: string;
  lessons: Lesson[];
};

export type CourseDraft = {
  title: string;
  level: Level;
  coverFile: File | null;
  coverPreview: string | null;
  learnings: string[];
  /** 🔥 un seul champ de description (HTML) */
  description: string;
  modules: Module[];
  priceType: "free" | "paid";
  currency: string;
  price?: number;
};
