// C:\Users\ADMIN\Desktop\fullmargin-site\src\pages\communaute\private\community-details\tabs\Formations\steps\Step4Curriculum.tsx
import { useState } from "react";
import type { CurriculumItem, Lesson, Module } from "../types";
import {
  Plus,
  Trash2,
  ChevronDown,
  ChevronRight,
  FileVideo2,
  FileText,
  ExternalLink,
} from "lucide-react";

const uid = () => Math.random().toString(36).slice(2, 9);

/** Item enrichi pour l'UI (fichiers, mirroirs, etc.) */
type UIItem = CurriculumItem & {
  file?: File | null;
  filename?: string | null;
  __serializedFile?: {
    dataUrl: string;
    name?: string;
    type?: string;
    lastModified?: number;
  } | null;
  url?: string | null;
  durationMin?: number;
};

/** Test média pour items (évite instanceof → pas d’erreur TS2358) */
const hasAnyMedia = (it: Partial<UIItem>) => {
  const f = it?.file as unknown;
  const hasFile =
    !!f &&
    typeof f === "object" &&
    typeof (f as Record<string, unknown>).name === "string" &&
    typeof (f as Record<string, unknown>).size === "number";
  const hasMirror = !!it?.__serializedFile?.dataUrl;
  const hasUrl = typeof it?.url === "string" && it.url.trim().length > 0;
  const hasName = typeof it?.filename === "string" && it.filename.length > 0;
  return hasFile || hasMirror || hasUrl || hasName;
};

/** Extraire un nom “lisible” depuis une URL (dernier segment décodé, sans query/hash) */
function nameFromUrl(raw?: string | null): string | null {
  if (!raw) return null;
  try {
    const u = new URL(raw);
    const last = u.pathname.split("/").filter(Boolean).pop() || "";
    return decodeURIComponent(last || raw);
  } catch {
    // URL relative ou chaîne brute
    const noHash = raw.split("#")[0];
    const noQuery = noHash.split("?")[0];
    const last = noQuery.split("/").filter(Boolean).pop() || "";
    return last || raw;
  }
}

/** Nom à afficher en priorité (sélection locale > miroir > filename > url) */
function displaySelectedName(it: Partial<UIItem>): string | null {
  const f = it?.file as unknown;
  const fileName =
    !!f &&
    typeof f === "object" &&
    typeof (f as Record<string, unknown>).name === "string"
      ? (f as Record<string, unknown>).name
      : null;
  if (fileName) return String(fileName);

  const mirrorName =
    typeof it?.__serializedFile?.name === "string"
      ? it?.__serializedFile?.name
      : null;
  if (mirrorName && mirrorName.trim()) return mirrorName.trim();

  if (it?.filename && it.filename.trim()) return it.filename.trim();

  return null;
}

/** Nom “actuel” depuis l’URL distante (si rien n’a été sélectionné localement) */
function displayCurrentName(it: Partial<UIItem>): string | null {
  return nameFromUrl(it?.url ?? null);
}

/** Durée vidéo (secondes) */
function getVideoDurationSeconds(file: File): Promise<number> {
  return new Promise((resolve, reject) => {
    try {
      const url = URL.createObjectURL(file);
      const video = document.createElement("video");
      video.preload = "metadata";
      video.onloadedmetadata = () => {
        const secs = video.duration;
        URL.revokeObjectURL(url);
        resolve(Number.isFinite(secs) ? secs : 0);
      };
      video.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error("Durée vidéo indisponible"));
      };
      video.src = url;
    } catch (e) {
      reject(e);
    }
  });
}

type Props = {
  modules: Module[];
  onChange: (modules: Module[]) => void;
};

export default function Step4Curriculum({ modules, onChange }: Props) {
  const safeModules: Module[] = Array.isArray(modules) ? modules : [];
  const patchModules = (next: Module[]) => onChange(next);

  const [openIds, setOpenIds] = useState<Set<string>>(
    () => new Set<string>([safeModules[0]?.id].filter(Boolean) as string[])
  );
  const toggleOpen = (id: string) =>
    setOpenIds((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  const setModule = (mid: string, p: Partial<Module>) =>
    patchModules(safeModules.map((m) => (m.id === mid ? { ...m, ...p } : m)));

  const removeModule = (mid: string) =>
    patchModules(safeModules.filter((m) => m.id !== mid));

  const addModule = () =>
    patchModules([
      ...safeModules,
      { id: uid(), title: "Nouveau module", description: "", lessons: [] },
    ]);

  const addLesson = (mid: string) => {
    const m = safeModules.find((x) => x.id === mid);
    const lessons = Array.isArray(m?.lessons) ? m!.lessons : [];
    setModule(mid, {
      lessons: [
        ...lessons,
        { id: uid(), title: "Nouvelle leçon", description: "", items: [] },
      ],
    });
  };

  const setLesson = (mid: string, lid: string, p: Partial<Lesson>) => {
    const m = safeModules.find((x) => x.id === mid);
    const lessons = Array.isArray(m?.lessons) ? m!.lessons : [];
    setModule(mid, {
      lessons: lessons.map((l) => (l.id === lid ? { ...l, ...p } : l)),
    });
  };

  const removeLesson = (mid: string, lid: string) => {
    const m = safeModules.find((x) => x.id === mid);
    const lessons = Array.isArray(m?.lessons) ? m!.lessons : [];
    setModule(mid, { lessons: lessons.filter((x) => x.id !== lid) });
  };

  const addItem = (mid: string, lid: string, type: "video" | "pdf") => {
    const m = safeModules.find((x) => x.id === mid);
    const l = (Array.isArray(m?.lessons) ? m!.lessons : []).find(
      (x) => x.id === lid
    );
    const items = Array.isArray(l?.items) ? (l!.items as UIItem[]) : [];
    setLesson(mid, lid, {
      items: [
        ...items,
        { id: uid(), type, title: type.toUpperCase() } as UIItem,
      ],
    });
  };

  const setItem = (
    mid: string,
    lid: string,
    iid: string,
    p: Partial<UIItem> & Record<string, unknown>
  ) => {
    const m = safeModules.find((x) => x.id === mid);
    const l = (Array.isArray(m?.lessons) ? m!.lessons : []).find(
      (x) => x.id === lid
    );
    const items = Array.isArray(l?.items) ? (l!.items as UIItem[]) : [];
    setLesson(mid, lid, {
      items: items.map((it) =>
        it.id === iid ? { ...(it as UIItem), ...p } : it
      ) as unknown as CurriculumItem[],
    });
  };

  const removeItem = (mid: string, lid: string, iid: string) => {
    const m = safeModules.find((x) => x.id === mid);
    const l = (Array.isArray(m?.lessons) ? m!.lessons : []).find(
      (x) => x.id === lid
    );
    const items = Array.isArray(l?.items) ? (l!.items as UIItem[]) : [];
    setLesson(mid, lid, {
      items: items.filter((it) => it.id !== iid) as unknown as CurriculumItem[],
    });
  };

  const onLessonItemFile = async (
    mid: string,
    lid: string,
    iid: string,
    type: "video" | "pdf",
    file: File | null | undefined
  ) => {
    setItem(mid, lid, iid, {
      file: file ?? null,
      filename: file?.name ?? null,
    });

    if (file) {
      try {
        const toDataUrl = (f: File) =>
          new Promise<string>((resolve, reject) => {
            const r = new FileReader();
            r.onload = () => resolve(String(r.result));
            r.onerror = () => reject(r.error);
            r.readAsDataURL(f);
          });
        const dataUrl = await toDataUrl(file);
        setItem(mid, lid, iid, {
          __serializedFile: {
            dataUrl,
            name: file.name,
            type: file.type,
            lastModified: file.lastModified,
          },
        });
      } catch {
        /* ignore */
      }
    } else {
      setItem(mid, lid, iid, { __serializedFile: null });
    }

    if (file && type === "video") {
      try {
        const sec = await getVideoDurationSeconds(file);
        setItem(mid, lid, iid, {
          durationMin: Math.max(1, Math.round((Number(sec) || 0) / 60)),
        });
      } catch {
        setItem(mid, lid, iid, { durationMin: undefined });
      }
    } else if (type === "pdf") {
      setItem(mid, lid, iid, { durationMin: undefined });
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto] items-start gap-2 sm:gap-3">
        <h3 className="font-medium leading-snug text-[15px] sm:text-base">
          Contenu du cours
        </h3>
        <button
          onClick={addModule}
          className="justify-self-start sm:justify-self-end inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm bg-violet-600 text-white hover:bg-violet-700"
          title="Ajouter un module"
        >
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">Ajouter un module</span>
        </button>
      </div>

      <div className="space-y-3">
        {safeModules.map((m, idx) => {
          const isOpen = openIds.has(m.id);
          const altBg =
            idx % 2 === 0
              ? "bg-slate-900/30 dark:bg-slate-800/40"
              : "bg-slate-900/20 dark:bg-slate-800/30";
          const lessons: Lesson[] = Array.isArray(m.lessons) ? m.lessons : [];

          return (
            <div
              key={m.id}
              className={`rounded-2xl ring-1 ring-slate-200/60 dark:ring-slate-700/60 ${altBg}`}
            >
              <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto] items-start gap-2 sm:gap-3 p-4">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => toggleOpen(m.id)}
                    className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ring-1 ring-slate-300 dark:ring-slate-600 hover:bg-black/5 dark:hover:bg-white/10"
                    title={isOpen ? "Replier" : "Déplier"}
                    aria-label={isOpen ? "Replier" : "Déplier"}
                  >
                    {isOpen ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                  </button>

                  <input
                    className="w-full rounded-xl px-3 py-2 bg-slate-50 dark:bg-slate-800 ring-1 ring-slate-200 dark:ring-slate-700 outline-none"
                    value={m.title}
                    onChange={(e) => setModule(m.id, { title: e.target.value })}
                  />
                </div>

                <div className="flex gap-2 justify-self-start sm:justify-self-end">
                  <button
                    onClick={() => addLesson(m.id)}
                    className="inline-flex h-9 w-9 items-center justify-center rounded-lg ring-1 ring-slate-300 dark:ring-slate-600 hover:bg-black/5 dark:hover:bg-white/10"
                    title="Ajouter une leçon"
                    aria-label="Ajouter une leçon"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => removeModule(m.id)}
                    className="inline-flex h-9 w-9 items-center justify-center rounded-lg ring-1 ring-rose-300 text-rose-600 dark:ring-rose-700 hover:bg-rose-500/10"
                    title="Supprimer le module"
                    aria-label="Supprimer le module"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {isOpen && (
                <div className="px-4 pb-4 space-y-3">
                  <textarea
                    placeholder="Description du module…"
                    rows={3}
                    value={m.description ?? ""}
                    onChange={(e) =>
                      setModule(m.id, { description: e.target.value })
                    }
                    className="w-full rounded-xl px-3 py-2 bg-white/80 dark:bg-slate-900/70 ring-1 ring-slate-200 dark:ring-slate-700 outline-none"
                  />

                  {lessons.map((l) => {
                    const items: UIItem[] = Array.isArray(l.items)
                      ? (l.items as UIItem[])
                      : [];
                    return (
                      <div
                        key={l.id}
                        className="rounded-xl p-3 ring-1 ring-slate-200 dark:ring-slate-700 bg-slate-50/70 dark:bg-slate-800/60"
                      >
                        <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto] items-start gap-2 sm:gap-3">
                          <input
                            className="w-full rounded-xl px-3 py-2 bg-white dark:bg-slate-900 ring-1 ring-slate-200 dark:ring-slate-700 outline-none"
                            value={l.title}
                            onChange={(e) =>
                              setLesson(m.id, l.id, { title: e.target.value })
                            }
                          />
                          <div className="flex gap-2 justify-self-start sm:justify-self-end">
                            <button
                              onClick={() => addItem(m.id, l.id, "video")}
                              className="inline-flex h-9 w-9 items-center justify-center rounded-lg ring-1 ring-slate-300 dark:ring-slate-600 hover:bg-black/5 dark:hover:bg-white/10"
                              title="Ajouter une vidéo"
                              aria-label="Ajouter une vidéo"
                            >
                              <FileVideo2 className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => addItem(m.id, l.id, "pdf")}
                              className="inline-flex h-9 w-9 items-center justify-center rounded-lg ring-1 ring-slate-300 dark:ring-slate-600 hover:bg-black/5 dark:hover:bg-white/10"
                              title="Ajouter un PDF"
                              aria-label="Ajouter un PDF"
                            >
                              <FileText className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => removeLesson(m.id, l.id)}
                              className="inline-flex h-9 w-9 items-center justify-center rounded-lg ring-1 ring-rose-300 text-rose-600 dark:ring-rose-700 hover:bg-rose-500/10"
                              title="Supprimer la leçon"
                              aria-label="Supprimer la leçon"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>

                        <textarea
                          placeholder="Description de la leçon…"
                          rows={3}
                          value={l.description ?? ""}
                          onChange={(e) =>
                            setLesson(m.id, l.id, {
                              description: e.target.value,
                            })
                          }
                          className="mt-2 w-full rounded-xl px-3 py-2 ring-1 outline-none bg-white dark:bg-slate-900 ring-slate-200 dark:ring-slate-700"
                        />

                        <div className="mt-2 space-y-2">
                          {items.map((it) => {
                            const mediaOk = hasAnyMedia(it);
                            const selectedName = displaySelectedName(it);
                            const currentName = !selectedName
                              ? displayCurrentName(it)
                              : null;
                            const hasUrl = typeof it.url === "string" && it.url;

                            return (
                              <div
                                key={it.id}
                                className="grid sm:grid-cols-[110px,1fr,1fr,120px,auto] gap-2"
                              >
                                <span className="text-xs inline-flex items-center justify-center rounded-md px-2 py-1 bg-slate-900 text-white dark:bg-slate-700">
                                  {it.type.toUpperCase()}
                                </span>

                                <input
                                  className="rounded-lg px-3 py-1.5 bg-white dark:bg-slate-900 ring-1 ring-slate-200 dark:ring-slate-700 outline-none"
                                  placeholder="Titre"
                                  value={it.title}
                                  onChange={(e) =>
                                    setItem(m.id, l.id, it.id, {
                                      title: e.target.value,
                                    })
                                  }
                                />

                                <div>
                                  <input
                                    type="file"
                                    accept={
                                      it.type === "video"
                                        ? "video/mp4,video/*"
                                        : "application/pdf"
                                    }
                                    onChange={(e) =>
                                      onLessonItemFile(
                                        m.id,
                                        l.id,
                                        it.id,
                                        it.type,
                                        e.target.files?.[0] ?? null
                                      )
                                    }
                                    className={`w-full rounded-lg px-3 py-1.5 ring-1 outline-none ${
                                      mediaOk
                                        ? "bg-white dark:bg-slate-900 ring-slate-200 dark:ring-slate-700"
                                        : "bg-rose-50 dark:bg-rose-900/20 ring-rose-300 dark:ring-rose-700"
                                    }`}
                                  />

                                  {/* LIGNE D'INFO NOM + LIEN */}
                                  {selectedName ? (
                                    <div className="text-xs text-slate-700 dark:text-slate-300 mt-1">
                                      <span className="font-medium">
                                        Sélectionné :
                                      </span>{" "}
                                      {selectedName}
                                    </div>
                                  ) : currentName ? (
                                    <div className="text-xs text-slate-600 mt-1 flex items-center gap-2">
                                      <span>
                                        <span className="font-medium">
                                          Actuel :
                                        </span>{" "}
                                        {currentName}
                                      </span>
                                      {hasUrl ? (
                                        <a
                                          href={it.url!}
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          className="inline-flex items-center gap-1 underline decoration-dotted"
                                          title="Ouvrir"
                                        >
                                          <ExternalLink className="h-3.5 w-3.5" />
                                          Ouvrir
                                        </a>
                                      ) : null}
                                    </div>
                                  ) : (
                                    <div className="text-xs text-slate-500 mt-1">
                                      Aucun fichier choisi.
                                    </div>
                                  )}
                                </div>

                                {it.type === "video" ? (
                                  <input
                                    type="number"
                                    readOnly
                                    value={it.durationMin ?? ""}
                                    placeholder="Auto"
                                    className="rounded-lg px-3 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-600 ring-1 ring-slate-200 dark:ring-slate-700 outline-none"
                                    title="Durée auto (minutes)"
                                  />
                                ) : (
                                  <div />
                                )}

                                <button
                                  onClick={() => removeItem(m.id, l.id, it.id)}
                                  className="px-3 py-1.5 rounded-lg ring-1 ring-slate-300 dark:ring-slate-600"
                                  title="Retirer l’élément"
                                >
                                  Retirer
                                </button>
                              </div>
                            );
                          })}
                          {items.length === 0 && (
                            <div className="text-xs text-slate-500">
                              Ajoute au moins une ressource.
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}

        {safeModules.length === 0 && (
          <div className="text-sm text-slate-500">
            Ajoute ton premier module.
          </div>
        )}
      </div>
    </div>
  );
}
