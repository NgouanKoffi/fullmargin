// C:\Users\ADMIN\Desktop\fullmargin-site\src\pages\communaute\private\community-details\tabs\Formations\FormationsWizard.tsx
import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft } from "lucide-react";

import ProgressSteps from "./composants/ProgressSteps";
import BottomBar from "./composants/BottomBar";
import Step1Infos from "./steps/Step1Infos";
import Step2Learnings from "./steps/Step2Learnings";
import Step3Descriptions from "./steps/Step3Descriptions";
import Step4Curriculum from "./steps/Step4Curriculum";
import Step5Tarif from "./steps/Step5Tarifs";

// types (type-only)
import type { CourseDraft, Module, Level } from "./types";
import type { CourseSaved } from "../../api/formations.api";
import type { CI } from "./autres/formations.media.ts";
import type { Step } from "./autres/formations.validation.ts";

// runtime
import {
  createCourseMultipart,
  updateCourseMultipart,
} from "../../api/formations.api";
import {
  reviveFile,
  serializeFile,
  mergeModulesPreserveMedia,
} from "./autres/formations.media.ts";
import {
  validateAll,
  isRichTextEmpty, // ⬅️ on réutilise les helpers exportés
} from "./autres/formations.validation.ts";

/* ===== persist draft in localStorage ===== */
const STORAGE_KEY_DRAFT = "fm:course-draft";
type DraftMeta = { id?: string; createdAt?: string };
export type { CourseSaved };

type SerializedUIItem = {
  id: string;
  type: "video" | "pdf";
  title: string;
  durationMin?: number;
  url: string | null;
  filename: string | null;
  __serializedFile:
    | import("./autres/formations.media.ts").SerializedFile
    | null;
};
type PersistedLesson = {
  id: string;
  title: string;
  description: string;
  items: SerializedUIItem[];
};
type PersistedModule = {
  id: string;
  title: string;
  description: string;
  lessons: PersistedLesson[];
};
type PersistedDraftForStorage = Omit<CourseDraft, "coverFile" | "modules"> & {
  __coverFileSerialized:
    | import("./autres/formations.media.ts").SerializedFile
    | null;
  modules: PersistedModule[];
};

const allowedLevels: Level[] = [
  "Débutant",
  "Intermédiaire",
  "Avancé",
  "Tous niveaux",
];
const ensureLevel = (v: string): Level =>
  (allowedLevels as string[]).includes(v) ? (v as Level) : "Tous niveaux";

export default function FormationsWizardInner({
  communityId,
  initialDraft,
  editingMeta,
  onCancel,
  onSaved,
}: {
  communityId: string;
  initialDraft: CourseDraft | null;
  editingMeta?: DraftMeta;
  onCancel: () => void;
  onSaved: (saved: CourseSaved) => void;
}) {
  const [step, setStep] = useState<Step>(1);
  const [notice, setNotice] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const [saving, setSaving] = useState(false);
  const lastSavedRef = useRef<string | null>(null);

  // 🔒 état “sauvegarde en cours” de l’étape 3 + flush fourni par Step3
  const [pendingSave, setPendingSave] = useState(false);
  const flushStep3Ref = useRef<null | (() => Promise<string>)>(null);

  // état initial avec un seul champ description
  const [draft, setDraft] = useState<CourseDraft>(() => ({
    title: "",
    level: "Tous niveaux",
    coverFile: null,
    coverPreview: null,
    learnings: [],
    description: "", // ✅ unique
    modules: [],
    priceType: "free",
    currency: "USD",
    price: undefined,
  }));

  useEffect(() => {
    if (initialDraft) setDraft(initialDraft);
  }, [initialDraft]);

  // hydrate from LS if not editing existing draft
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (initialDraft) {
          setHydrated(true);
          return;
        }
        const raw = localStorage.getItem(STORAGE_KEY_DRAFT);
        if (!raw) {
          setHydrated(true);
          return;
        }

        // on lit le format courant + on tolère l'ancien (shortDesc/longDesc)
        type LegacyDesc = {
          description?: string;
          shortDesc?: string;
          longDesc?: string;
        };
        const saved = JSON.parse(raw) as PersistedDraftForStorage &
          Partial<LegacyDesc>;

        const revivedCover = reviveFile(saved.__coverFileSerialized ?? null);
        const coverPreview = revivedCover
          ? URL.createObjectURL(revivedCover)
          : null;

        const revivedModules: Module[] = (saved.modules ?? []).map((m) => ({
          id: m.id,
          title: m.title,
          description: m.description,
          lessons: (m.lessons ?? []).map((l) => ({
            id: l.id,
            title: l.title,
            description: l.description,
            items: l.items.map((it) => ({
              id: it.id,
              type: it.type,
              title: it.title,
              url: it.url ?? "",
              filename: it.filename,
              file: reviveFile(it.__serializedFile ?? null),
              __serializedFile: it.__serializedFile,
              durationMin: it.durationMin,
            })) as unknown as import("./types").CurriculumItem[],
          })),
        }));

        // migration → priorité au nouveau champ
        const migratedDescription =
          (saved.description && saved.description.trim()) ||
          (saved.longDesc && saved.longDesc.trim()) ||
          (saved.shortDesc && saved.shortDesc.trim()) ||
          "";

        if (!cancelled) {
          setDraft((d) => ({
            ...d,
            title: saved.title,
            level: ensureLevel(saved.level as unknown as string),
            coverFile: revivedCover,
            coverPreview,
            learnings: saved.learnings ?? [],
            description: migratedDescription, // ✅ unique
            modules: revivedModules,
            priceType: saved.priceType,
            currency: "USD",
            price: saved.price,
          }));
          setHydrated(true);
        }
      } catch {
        if (!cancelled) setHydrated(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [initialDraft]);

  // persist to LS (écrit uniquement description + programme + meta)
  useEffect(() => {
    if (!hydrated) return;
    let cancelled = false;
    (async () => {
      try {
        const persisted: PersistedDraftForStorage = {
          title: draft.title,
          level: draft.level,
          coverPreview: draft.coverPreview,
          learnings: draft.learnings,
          description: draft.description, // ✅ unique
          modules: await Promise.all(
            draft.modules.map(async (m) => ({
              id: m.id,
              title: m.title,
              description: m.description || "",
              lessons: await Promise.all(
                (m.lessons ?? []).map(async (l) => ({
                  id: l.id,
                  title: l.title,
                  description: l.description || "",
                  items: await Promise.all(
                    (l.items as unknown as CI[]).map(async (it) => ({
                      id: it.id,
                      type: it.type,
                      title: it.title,
                      durationMin: it.durationMin,
                      url: it.url ?? null,
                      filename: it.filename ?? null,
                      __serializedFile: it.file
                        ? await serializeFile(it.file)
                        : it.__serializedFile ?? null,
                    }))
                  ),
                }))
              ),
            }))
          ),
          priceType: draft.priceType,
          currency: "USD",
          price: draft.price,
          __coverFileSerialized: draft.coverFile
            ? await serializeFile(draft.coverFile)
            : null,
        };

        const json = JSON.stringify(persisted);
        if (!cancelled && json !== lastSavedRef.current) {
          localStorage.setItem(STORAGE_KEY_DRAFT, json);
          lastSavedRef.current = json;
        }
      } catch {
        /* ignore */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [draft, hydrated]);

  const patch = (p: Partial<CourseDraft>) => setDraft((d) => ({ ...d, ...p }));
  const byStep = useMemo(() => validateAll(draft).byStep, [draft]);
  const maxStepAllowed: Step = useMemo(
    () =>
      !byStep[1].ok
        ? 1
        : !byStep[2].ok
        ? 2
        : !byStep[3].ok
        ? 3
        : !byStep[4].ok
        ? 4
        : 5,
    [byStep]
  );
  const currentValid =
    (step === 1 && byStep[1].ok) ||
    (step === 2 && byStep[2].ok) ||
    (step === 3 && byStep[3].ok) ||
    (step === 4 && byStep[4].ok) ||
    (step === 5 && byStep[5].ok);
  const allValid =
    byStep[1].ok &&
    byStep[2].ok &&
    byStep[3].ok &&
    byStep[4].ok &&
    byStep[5].ok;

  const stepName = (s: Step) =>
    ({
      1: "Infos",
      2: "Apprentissages",
      3: "Descriptions",
      4: "Programme",
      5: "Tarif",
    }[s]);
  const buildErrorText = (s: Step) => {
    const msgs = byStep[s].messages;
    return msgs.length === 0
      ? `Complète les champs requis de l’étape “${stepName(s)}”.`
      : `Étape “${stepName(s)}” :\n- ${msgs.join("\n- ")}`;
  };

  // Navigation
  const goPrev = async () => {
    if (step === 3 && flushStep3Ref.current) {
      await flushStep3Ref.current();
    }
    if (pendingSave) return;
    setStep((s) => Math.max(1, Math.min(5, s - 1)) as Step);
  };

  const goNext = async () => {
    // Forcer un flush à l’étape 3 et valider le texte
    if (step === 3 && flushStep3Ref.current) {
      const html = await flushStep3Ref.current();
      if (isRichTextEmpty(html)) {
        setNotice("Renseigne la description du cours.");
        return;
      }
    }
    if (pendingSave) {
      setNotice("Patiente… la description est en cours d’enregistrement.");
      return;
    }
    if (currentValid) {
      setNotice(null);
      setStep((s) => Math.max(1, Math.min(5, s + 1)) as Step);
    } else {
      setNotice(buildErrorText(step));
    }
  };

  // clic dans la barre d’étapes : verrouillé si invalide/pending
  const attemptJump = async (n: number) => {
    if (n > maxStepAllowed) return;
    if (step === 3 && flushStep3Ref.current) {
      const html = await flushStep3Ref.current();
      if (isRichTextEmpty(html)) {
        setNotice("Renseigne la description du cours.");
        return;
      }
    }
    if (pendingSave) return;
    if (n > step && !currentValid) {
      setNotice(buildErrorText(step));
      return;
    }
    setNotice(null);
    setStep(() => Math.max(1, Math.min(5, n)) as Step);
  };

  const submitFormation = async () => {
    const vAll = validateAll(draft);
    if (!vAll.ok) {
      const firstInvalid = (Object.keys(vAll.byStep) as unknown as Step[]).find(
        (k) => !vAll.byStep[k].ok
      ) as Step;
      setStep(firstInvalid);
      setNotice(buildErrorText(firstInvalid));
      return;
    }
    try {
      setSaving(true);
      if (!editingMeta?.id) {
        if (!draft.coverFile && !draft.coverPreview) {
          setNotice("Ajoute une photo de couverture.");
          setSaving(false);
          return;
        }
        const created = await createCourseMultipart(communityId, draft);
        localStorage.removeItem(STORAGE_KEY_DRAFT);
        onSaved(created);
      } else {
        const updated = await updateCourseMultipart(editingMeta.id, draft);
        localStorage.removeItem(STORAGE_KEY_DRAFT);
        onSaved(updated);
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Échec de la sauvegarde.";
      setNotice(msg);
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="mx-auto w-full max-w-[1380px] px-3 sm:px-6 lg:px-10 space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">
          {editingMeta?.id ? "Modifier la formation" : "Éditeur de formation"}
        </h2>
        <button
          onClick={onCancel}
          className="inline-flex items-center justify-center p-2 rounded-lg ring-1 ring-slate-300 hover:bg-black/5 disabled:opacity-50 dark:ring-slate-600 dark:hover:bg-white/10"
          title="Retour"
          aria-label="Retour"
          disabled={saving}
        >
          <ArrowLeft className="h-4 w-4" />
        </button>
      </div>

      <ProgressSteps
        step={step}
        total={5}
        onJump={attemptJump}
        className="mb-2"
        maxStepAllowed={maxStepAllowed}
      />

      {notice && (
        <div className="rounded-xl border border-amber-300/60 bg-amber-50/70 text-amber-900 dark:border-amber-400/40 dark:bg-amber-400/10 dark:text-amber-200 p-3 whitespace-pre-line">
          {notice}
        </div>
      )}

      {step === 1 && <Step1Infos data={draft} onChange={patch} />}
      {step === 2 && <Step2Learnings data={draft} onChange={patch} />}
      {step === 3 && (
        <Step3Descriptions
          data={draft}
          onChange={patch}
          onPendingChange={setPendingSave}
          onProvideFlush={(fn) => (flushStep3Ref.current = fn)}
        />
      )}
      {step === 4 && (
        <Step4Curriculum
          modules={draft.modules}
          onChange={(mods) =>
            setDraft((d) => ({
              ...d,
              modules: mergeModulesPreserveMedia(d.modules, mods),
            }))
          }
        />
      )}
      {step === 5 && (
        <Step5Tarif
          data={draft}
          onChange={patch}
          onSubmit={submitFormation}
          canSubmit={allValid && !saving}
          isEdit={Boolean(editingMeta?.id)}
        />
      )}

      <BottomBar
        onPrev={goPrev}
        onNext={goNext}
        disableNext={!currentValid || pendingSave}
      />
    </section>
  );
}
