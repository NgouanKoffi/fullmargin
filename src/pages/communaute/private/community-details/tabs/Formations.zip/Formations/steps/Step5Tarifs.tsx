// src/pages/communaute/private/community-details/tabs/Formations/steps/Step5Tarifs.tsx
import type { CourseDraft } from "../types";

type Props = {
  data: CourseDraft;
  onChange: (patch: Partial<CourseDraft>) => void;
  onSubmit: () => void; // bouton final
  /** Si toutes les étapes sont valides, active le bouton */
  canSubmit: boolean;
  /** Afficher "Mettre à jour" quand on édite une formation existante */
  isEdit?: boolean;
};

// const FEE_RATE = 0.05; // 5% (désactivé pour l'instant)
// const MIN_PRICE = 20; // ✅ Minimum 20 USD (désactivé pour l'instant)

export default function Step5Tarif({
  data,
  onChange,
  onSubmit,
  canSubmit,
  isEdit,
}: Props) {
  const toFree = () =>
    onChange({ priceType: "free", price: 0, currency: "USD" });

  const toPaid = () =>
    onChange({
      priceType: "paid",
      price: 0, // on bloque à 0 pour le moment
      currency: "USD",
    });

  // const price = typeof data.price === "number" ? data.price : 0;
  // const net =
  //   data.priceType === "paid" ? Math.max(0, price * (1 - FEE_RATE)) : 0;
  // const priceIsValid =
  //   data.priceType === "free" ||
  //   (price >= MIN_PRICE && Number.isFinite(price));

  // comme on force gratuit / 0, on met simple :
  const priceIsValid = true;

  return (
    <div className="rounded-2xl p-4 sm:p-5 ring-1 ring-slate-200 dark:ring-slate-700 bg-white/70 dark:bg-slate-900/60 space-y-6">
      {/* Type de tarif */}
      <div className="space-y-2">
        <label className="block text-sm font-medium">Type de tarif</label>
        <div className="inline-flex rounded-lg ring-1 ring-slate-300 dark:ring-slate-600 overflow-hidden">
          <button
            onClick={toFree}
            className={
              "px-4 py-1.5 text-sm " +
              (data.priceType === "free" || !data.priceType
                ? "bg-emerald-600 text-white"
                : "bg-transparent text-slate-700 dark:text-slate-200")
            }
          >
            Gratuit
          </button>
          <button
            onClick={toPaid}
            className={
              "px-4 py-1.5 text-sm " +
              (data.priceType === "paid"
                ? "bg-violet-600 text-white"
                : "bg-transparent text-slate-700 dark:text-slate-200")
            }
          >
            Payant
          </button>
        </div>
      </div>

      {/* Prix (USD only) + frais */}
      {data.priceType === "paid" && (
        <div className="grid gap-3 max-w-lg">
          <div className="space-y-1.5">
            <label className="block text-sm font-medium">Prix (USD)</label>
            <div className="relative">
              <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">
                $
              </span>
              <input
                type="number"
                // min={MIN_PRICE}
                // step="0.01"
                value={0}
                onChange={() => {
                  /* bloqué */
                }}
                disabled
                className="w-full pl-7 rounded-xl px-3 py-2 bg-slate-50 dark:bg-slate-800 ring-1 outline-none ring-slate-200 dark:ring-slate-700"
                aria-invalid={false}
                // aria-describedby="price-help"
              />
            </div>
            <p className="text-xs text-red-500">
              Pour l&apos;instant, vous ne pouvez créer que des formations
              gratuites.
            </p>
            {/* <p id="price-help" className="text-xs text-slate-500">
              Minimum accepté : <strong>${MIN_PRICE.toFixed(2)}</strong>
            </p> */}
          </div>

          <div className="rounded-xl ring-1 ring-slate-200 dark:ring-slate-700 bg-slate-50/70 dark:bg-slate-800/50 p-3 text-sm">
            <div className="flex items-center justify-between">
              <span>Frais plateforme (5 %)</span>
              <span>$0.00</span>
              {/* <span>${(price * FEE_RATE || 0).toFixed(2)}</span> */}
            </div>
            <div className="mt-1 flex items-center justify-between font-medium">
              <span>Vous percevrez</span>
              <span>$0.00 / vente</span>
              {/* <span>${(priceIsValid ? net : 0).toFixed(2)} / vente</span> */}
            </div>
          </div>
        </div>
      )}

      {/* Bouton final */}
      <div className="pt-2 flex justify-end">
        <button
          type="button"
          onClick={onSubmit}
          disabled={!canSubmit || !priceIsValid}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-violet-600 text-white hover:bg-violet-700 disabled:opacity-50"
          title={
            canSubmit && priceIsValid
              ? isEdit
                ? "Mettre à jour la formation"
                : "Créer la formation"
              : "Complète d’abord les étapes obligatoires"
          }
        >
          {isEdit ? "Mettre à jour" : "Créer la formation"}
        </button>
      </div>
    </div>
  );
}
