// src/pages/communaute/private/community-details/tabs/Formations/steps/Step1Infos.tsx
import { useRef } from "react";
import type { CourseDraft, Level } from "../types";
import {
  Image as ImageIcon,
  X,
  Upload,
  ChevronDown,
  AlertTriangle,
} from "lucide-react";

const LEVELS: Level[] = ["Tous niveaux", "Débutant", "Intermédiaire", "Avancé"];
const TITLE_MAX = 120;
const COVER_MAX_MB = 2;

export default function Step1Infos({
  data,
  onChange,
}: {
  data: CourseDraft;
  onChange: (patch: Partial<CourseDraft>) => void;
}) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const openPicker = () => inputRef.current?.click();

  const hasCover = !!data.coverFile || !!data.coverPreview; // ✅ obligatoire

  const onFile = (f?: File | null) => {
    if (!f) return;
    if (!/^image\/(png|jpe?g)$/i.test(f.type)) {
      return alert("Formats autorisés : JPG/PNG.");
    }
    if (f.size > COVER_MAX_MB * 1024 * 1024) {
      return alert(`Image trop lourde (max ${COVER_MAX_MB} Mo).`);
    }
    const url = URL.createObjectURL(f);
    onChange({ coverFile: f, coverPreview: url });
  };

  const clearCover = () => {
    onChange({ coverFile: null, coverPreview: null });
  };

  return (
    <div className="space-y-5">
      {/* Couverture (OBLIGATOIRE) */}
      <section className="rounded-2xl ring-1 ring-slate-200 dark:ring-slate-700 bg-white dark:bg-slate-900 p-4 text-sm sm:text-base">
        {/* Titre + actions */}
        <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto] items-start gap-2 sm:gap-3 mb-3">
          <h3 className="font-medium break-words leading-snug text-[13px] sm:text-[15px]">
            Couverture (JPG/PNG, max {COVER_MAX_MB} Mo){" "}
            <span className="text-rose-600">*</span>
          </h3>

          <div className="flex items-center gap-2 justify-start sm:justify-end shrink-0">
            {!!data.coverPreview && (
              <button
                onClick={clearCover}
                className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs ring-1 ring-slate-300 dark:ring-slate-600 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
                title="Retirer l’image"
                type="button"
              >
                <X className="h-3.5 w-3.5" />
                Retirer
              </button>
            )}
            <button
              onClick={openPicker}
              aria-label="Choisir un fichier"
              title="Choisir un fichier"
              type="button"
              className="inline-flex items-center justify-center rounded-lg h-8 w-8 sm:h-9 sm:w-9 bg-violet-600 text-white hover:bg-violet-700"
            >
              <Upload className="h-4 w-4" />
            </button>
          </div>
        </div>

        <input
          ref={inputRef}
          type="file"
          accept="image/png,image/jpeg"
          className="hidden"
          onChange={(e) => onFile(e.target.files?.[0] ?? null)}
        />

        {/* Aperçu 16/9 avec état d'erreur si manquant */}
        <div
          onClick={openPicker}
          className={[
            "relative cursor-pointer rounded-xl overflow-hidden ring-2",
            hasCover
              ? "ring-slate-200 dark:ring-slate-700"
              : "ring-rose-400 dark:ring-rose-500",
            "bg-slate-50 dark:bg-slate-800",
          ].join(" ")}
          style={{ aspectRatio: "16/9" }}
        >
          {data.coverPreview ? (
            <img
              src={data.coverPreview}
              alt="Aperçu couverture"
              className="absolute inset-0 h-full w-full object-cover"
            />
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 gap-2">
              <ImageIcon className="h-5 w-5" />
              <span>Aucun aperçu</span>
            </div>
          )}
        </div>

        {!hasCover && (
          <p className="mt-2 inline-flex items-center gap-2 text-[12px] text-rose-600">
            <AlertTriangle className="h-4 w-4" />
            Image de couverture requise.
          </p>
        )}
      </section>

      {/* Titre + Niveau */}
      <section className="grid gap-4">
        <div className="rounded-2xl ring-1 ring-slate-200 dark:ring-slate-700 bg-white dark:bg-slate-900 p-4 text-sm sm:text-base">
          <label className="block text-[12px] sm:text-sm font-medium mb-2">
            Titre de la formation <span className="text-rose-600">*</span>
          </label>
          <input
            type="text"
            maxLength={TITLE_MAX}
            value={data.title}
            onChange={(e) => onChange({ title: e.target.value })}
            placeholder="Ex : React Native (2025) – Guide complet"
            className="w-full rounded-xl px-3 py-2 bg-slate-50 dark:bg-slate-800 ring-1 ring-slate-200 dark:ring-slate-700 outline-none"
          />
          <div className="mt-1 text-[11px] text-slate-500">
            {data.title.length}/{TITLE_MAX}
          </div>
        </div>

        <div className="rounded-2xl ring-1 ring-slate-200 dark:ring-slate-700 bg-white dark:bg-slate-900 p-4 text-sm sm:text-base">
          <label className="block text-[12px] sm:text-sm font-medium mb-2">
            Niveau <span className="text-rose-600">*</span>
          </label>
          <div className="relative">
            <select
              value={data.level}
              onChange={(e) => onChange({ level: e.target.value as Level })}
              className="w-full rounded-xl px-3 py-2 pr-9 bg-slate-50 dark:bg-slate-800 ring-1 ring-slate-200 dark:ring-slate-700 outline-none appearance-none"
            >
              {LEVELS.map((lv) => (
                <option key={lv} value={lv}>
                  {lv}
                </option>
              ))}
            </select>
            <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
          </div>
        </div>
      </section>
    </div>
  );
}
