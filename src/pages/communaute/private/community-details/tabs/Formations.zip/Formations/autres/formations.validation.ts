// C:\Users\ADMIN\Desktop\fullmargin-site\src\pages\communaute\private\community-details\tabs\Formations\autres\formations.validation.ts
import type { CourseDraft, Lesson } from "../types.ts";
import type { CI } from "./formations.media.ts";
import { itemHasMedia } from "./formations.media.ts";

export const MIN_LEARN_POINTS = 2;
export const MIN_PRICE_USD = 20;
export type Step = 1 | 2 | 3 | 4 | 5;

/* ========= Helpers (exportés pour ré-usage) ========= */
export function htmlToPlainText(html?: string | null): string {
  return (html ?? "")
    .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?>[\s\S]*?<\/style>/gi, " ")
    .replace(/<br\s*\/?>/gi, " ")
    .replace(/<\/p>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}
export function isRichTextEmpty(html?: string | null): boolean {
  return htmlToPlainText(html).length === 0;
}

/* ========= Step validations ========= */
export function validateStep1(d: CourseDraft) {
  const messages: string[] = [];
  if (!d.coverFile && !d.coverPreview)
    messages.push("Ajoute une photo de couverture (JPG/PNG).");
  if ((d.title ?? "").trim().length < 3)
    messages.push("Le titre doit contenir au moins 3 caractères.");
  if (!d.level) messages.push("Sélectionne un niveau.");
  return { ok: messages.length === 0, messages };
}

export function validateStep2(d: CourseDraft) {
  const messages: string[] = [];
  const learnings = d.learnings ?? [];
  if (learnings.length < MIN_LEARN_POINTS)
    messages.push(
      `Ajoute au moins ${MIN_LEARN_POINTS} points d’apprentissage.`
    );
  const empties = learnings
    .map((t, i) => ({ t: t ?? "", i }))
    .filter((x) => x.t.trim().length === 0)
    .map((x) => x.i + 1);
  if (empties.length > 0)
    messages.push(`Certains points sont vides : ${empties.join(", ")}.`);
  return { ok: messages.length === 0, messages };
}

export function validateStep3(d: CourseDraft) {
  const messages: string[] = [];
  // ✅ migration-friendly: unique description > legacy longDesc > legacy shortDesc
  const desc =
    (d as any).description ?? (d as any).longDesc ?? (d as any).shortDesc ?? "";
  if (isRichTextEmpty(desc)) {
    messages.push("Renseigne la description du cours.");
  }
  return { ok: messages.length === 0, messages };
}

function isEmptyItem(it: CI) {
  const title = ((it as any).title ?? "").trim();
  return title.length === 0 && !itemHasMedia(it);
}

function isLessonValid(l: Lesson, messages?: string[], path?: string) {
  const where = path ? ` (${path})` : "";
  let ok = true;
  if (!(l.title ?? "").trim()) {
    ok = false;
    messages?.push(`Une leçon sans titre${where}.`);
  }
  if (!(l.description ?? "").trim()) {
    ok = false;
    messages?.push(`Ajoute une description de leçon${where}.`);
  }
  const items = ((l.items as unknown as CI[]) ?? []).filter(
    (it) => !isEmptyItem(it)
  );
  if (items.length === 0) {
    ok = false;
    messages?.push(`La leçon${where} doit contenir au moins une ressource.`);
    return ok;
  }
  const videos = items.filter((it) => it.type === "video");
  const pdfs = items.filter((it) => it.type === "pdf");
  if (videos.length === 0) {
    ok = false;
    messages?.push(`La leçon${where} doit contenir au moins une vidéo.`);
  }
  if (pdfs.length === 0) {
    ok = false;
    messages?.push(`La leçon${where} doit contenir au moins un PDF.`);
  }
  items.forEach((it, idx) => {
    const nth = `#${idx + 1}${where}`;
    if (!((it as any).title ?? "").trim()) {
      ok = false;
      messages?.push(`Élément ${nth} sans titre.`);
    }
    if (!itemHasMedia(it)) {
      ok = false;
      messages?.push(
        `${it.type.toUpperCase()} ${nth} sans fichier ni URL (ou miroir).`
      );
    }
  });
  return ok;
}

export function validateStep4(d: CourseDraft) {
  const messages: string[] = [];
  const modules = d.modules ?? [];
  if (modules.length === 0) messages.push("Ajoute au moins un module.");
  modules.forEach((m, mi) => {
    const base = `Module ${mi + 1}`;
    if (!(m.title ?? "").trim()) messages.push(`${base} sans titre.`);
    if (!(m.description ?? "").trim())
      messages.push(`${base} sans description.`);
    const lessons = m.lessons ?? [];
    if (lessons.length < 2)
      messages.push(`${base} doit contenir au moins deux leçons.`);
    lessons.forEach((l, li) => {
      isLessonValid(l as Lesson, messages, `${base} > Leçon ${li + 1}`);
    });
  });
  return { ok: messages.length === 0, messages };
}

export function validateStep5(d: CourseDraft) {
  const messages: string[] = [];
  if (d.priceType === "paid") {
    if (!(typeof d.price === "number" && d.price >= MIN_PRICE_USD))
      messages.push(`Le prix doit être au moins ${MIN_PRICE_USD} USD.`);
  }
  return { ok: messages.length === 0, messages };
}

export function validateAll(d: CourseDraft) {
  const v1 = validateStep1(d),
    v2 = validateStep2(d),
    v3 = validateStep3(d),
    v4 = validateStep4(d),
    v5 = validateStep5(d);
  const ok = v1.ok && v2.ok && v3.ok && v4.ok && v5.ok;
  return {
    ok,
    byStep: { 1: v1, 2: v2, 3: v3, 4: v4, 5: v5 } as Record<
      Step,
      { ok: boolean; messages: string[] }
    >,
  };
}
