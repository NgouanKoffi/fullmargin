import { useEffect, useMemo, useRef } from "react";
import type { CourseDraft } from "../types";
import { useCreateBlockNote } from "@blocknote/react";
import { BlockNoteView } from "@blocknote/mantine";
import "@blocknote/react/style.css";
import "@blocknote/mantine/style.css";

/* ---------- debounce util ---------- */
function useDebounced<Args extends unknown[]>(
  cb: (...args: Args) => void,
  delay = 450
) {
  const t = useRef<number | null>(null);
  return (...args: Args) => {
    if (t.current) window.clearTimeout(t.current);
    t.current = window.setTimeout(() => cb(...args), delay);
  };
}

type DraftId = string | number | undefined;

export default function Step3Descriptions({
  data,
  onChange,
  onPendingChange,
  onProvideFlush,
}: {
  data: CourseDraft;
  onChange: (patch: Partial<CourseDraft>) => void;
  /** signale au parent qu’une save debouncée est en cours */
  onPendingChange?: (p: boolean) => void;
  /** donne au parent un flush() qui retourne le HTML immédiatement */
  onProvideFlush?: (fn: () => Promise<string>) => void;
}) {
  const editor = useCreateBlockNote();

  /** id stable de brouillon, pour ne charger qu’une fois */
  const dataId: DraftId = useMemo(() => {
    const maybe = data as Partial<{
      id: string | number;
      _id: string | number;
      draftId: string | number;
    }>;
    return maybe.id ?? maybe._id ?? maybe.draftId ?? undefined;
  }, [data]);

  /** push debouncé → met pending(true) puis false à la fin */
  const pushChange = useDebounced(async () => {
    const html = await editor.blocksToFullHTML(editor.document);
    onChange({ description: html });
    onPendingChange?.(false);
  }, 450);

  const handleChange = () => {
    onPendingChange?.(true);
    pushChange();
  };

  /** flush immédiat : retourne le HTML courant */
  const flushRef = useRef<() => Promise<string>>(async () => "");
  useEffect(() => {
    flushRef.current = async () => {
      onPendingChange?.(true);
      const html = await editor.blocksToFullHTML(editor.document);
      onChange({ description: html });
      onPendingChange?.(false);
      return html;
    };
    onProvideFlush?.(async () => flushRef.current());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editor, onChange]);

  /** charger le HTML existant une seule fois par brouillon */
  const loadedForRef = useRef<DraftId>(undefined);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (loadedForRef.current === dataId) return;
      const initialHtml = data.description || "";
      const blocks = initialHtml
        ? await editor.tryParseHTMLToBlocks(initialHtml)
        : [];
      if (!cancelled) {
        editor.replaceBlocks(editor.document, blocks);
        loadedForRef.current = dataId;
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataId, editor]);

  /** flush à l’unmount pour ne pas perdre la dernière frappe */
  useEffect(() => {
    return () => {
      flushRef.current?.();
    };
  }, []);

  return (
    <section className="grid gap-4 sm:gap-6">
      <div className="rounded-2xl ring-1 ring-black/10 dark:ring-white/10 bg-white dark:bg-slate-900 p-3 sm:p-4">
        <label className="block text-[13px] sm:text-sm font-medium mb-2 sm:mb-3">
          Description du cours
        </label>

        <div className="rounded-xl overflow-hidden ring-1 ring-black/5 dark:ring-white/10 bg-white dark:bg-slate-900">
          <BlockNoteView
            editor={editor}
            onChange={handleChange}
            className="bg-white dark:bg-slate-900 rounded-xl text-[15px] leading-relaxed break-words"
            style={{
              padding: "10px 12px", // padding droit raisonnable
              wordBreak: "break-word",
              overflowWrap: "anywhere",
            }}
          />
        </div>

        <p className="mt-2 text-[11px] sm:text-xs text-slate-500">
          Un seul champ de description, mise en forme complète.
        </p>
      </div>
    </section>
  );
}
