// ./Formations/steps/Step2Learnings.tsx
import type { CourseDraft } from "../types";
import { Plus, Trash2 } from "lucide-react";

const MAX_PER_ITEM = 130;
const MIN_POINTS = 2; // ✅ minimum ramené à 2
const MAX_POINTS = 12;

export default function Step2Learnings({
  data,
  onChange,
}: {
  data: CourseDraft;
  onChange: (patch: Partial<CourseDraft>) => void;
}) {
  const add = () => {
    if (data.learnings.length >= MAX_POINTS) return;
    onChange({ learnings: [...data.learnings, ""] });
  };

  const setItem = (idx: number, val: string) => {
    const arr = data.learnings.slice();
    arr[idx] = val.slice(0, MAX_PER_ITEM);
    onChange({ learnings: arr });
  };

  const remove = (idx: number) =>
    onChange({ learnings: data.learnings.filter((_, i) => i !== idx) });

  const canAddMore = data.learnings.length < MAX_POINTS;

  return (
    <section className="rounded-2xl p-4 sm:p-5 ring-1 ring-black/10 dark:ring-white/10 bg-white/60 dark:bg-white/5">
      {/* Titre + action : grid = pas de décalage */}
      <div className="mb-3 sm:mb-4 grid grid-cols-1 sm:grid-cols-[1fr_auto] items-start gap-2 sm:gap-3">
        <div>
          <h3 className="text-[15px] sm:text-lg font-semibold leading-snug">
            Ce que vos apprenants vont apprendre
          </h3>
          <p className="mt-1 text-[12px] sm:text-xs text-slate-500">
            {MIN_POINTS} à {MAX_POINTS} points • {MAX_PER_ITEM} caractères max
            par point
          </p>
        </div>

        <button
          type="button"
          onClick={add}
          disabled={!canAddMore}
          className="justify-self-start sm:justify-self-end inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm bg-violet-600 text-white hover:bg-violet-700 disabled:opacity-50 whitespace-nowrap"
          title={canAddMore ? "Ajouter un point" : "Limite atteinte"}
        >
          <Plus className="h-4 w-4" />
          Ajouter
        </button>
      </div>

      {/* LISTE EN PILE */}
      <div className="flex flex-col gap-4">
        {data.learnings.map((text, i) => {
          const left = MAX_PER_ITEM - text.length;
          return (
            <div
              key={i}
              className="rounded-xl ring-1 ring-black/10 dark:ring-white/10 bg-slate-50/60 dark:bg-slate-800/60 p-3 sm:p-4"
            >
              <div className="flex items-center justify-between gap-3">
                <span className="text-xs text-slate-500">Point {i + 1}</span>
                <button
                  type="button"
                  onClick={() => remove(i)}
                  className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs ring-1 ring-black/10 dark:ring-white/10 hover:bg-black/5 dark:hover:bg-white/10"
                  title="Supprimer"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Suppr
                </button>
              </div>

              <textarea
                rows={3}
                maxLength={MAX_PER_ITEM}
                value={text}
                onChange={(e) => setItem(i, e.target.value)}
                placeholder="Ex : Publier l’application sur le Play Store"
                className="mt-2 w-full rounded-lg px-3 py-2 bg-white dark:bg-slate-900 ring-1 ring-black/10 dark:ring-white/10 outline-none text-[15px] leading-relaxed"
              />

              <div className="mt-1 text-right text-[11px] text-slate-500">
                {left}
              </div>
            </div>
          );
        })}

        {data.learnings.length === 0 && (
          <div className="rounded-xl ring-1 ring-dashed ring-black/10 dark:ring-white/10 p-4 text-sm text-slate-500">
            Ajoutez au moins <strong>{MIN_POINTS}</strong> points clés de la
            formation.
          </div>
        )}
      </div>
    </section>
  );
}
